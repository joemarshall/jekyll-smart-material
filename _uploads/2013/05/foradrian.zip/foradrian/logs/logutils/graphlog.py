#!/usr/bin/env python
import wx
from NetSender import *
from CSVHolder import *
from SimpleGraph import *
from collections import deque
import sys
import os

from ConfigParser import *

from processors import *
from filters import *
from dtwfilter import *

class CSVGrapher(wx.Frame):

    def __init__(self, parent,filename,showDebug):
        wx.Frame.__init__(self, parent, title=filename)
        self.Maximize()
        self.showDebug=showDebug
        self.sourceFile=filename
        if filename==None:
            dlg = wx.FileDialog(
                    self, message="Choose a file",
                    defaultFile="",
                    defaultDir=os.getcwd(),
                    wildcard="CSV files (*.csv)|*.csv",
                    style=wx.OPEN  | wx.CHANGE_DIR
                    )
            if dlg.ShowModal() == wx.ID_OK:
                    filename = dlg.GetPath()
            else:
                self.Destroy()
                return
        
        self.inMarker=None
        self.outMarker=None
 
        print "load"
        self.holder=CSVHolder(filename,columnRenames=[("forwards_mps","forwards_mpsps")])

        self.leftPos=self.holder.getMinTime()
        
        self.rangeLength=10.0
        self.loadSettings()
        
        

        
        
        
        

#        print "stroke detect"
#        self.holder.runProcess(findStrokeProcessor())
        

        
#        print "independent component analysis"
 #       ica((magColumn,self.holder.getColumnFromName("roll_degrees")),self.holder)
        
        
#        print "particle filter"
#        dtwTracker(self.holder,self.inMarker,self.outMarker)

#        self.holder.runProcess(acceptFlatValuesProcessor(self.holder.getColumnFromName("roll_degrees"),5,self.holder.getColumnFromName("legangle_degrees"),magColumn))
#        smoothColumn=self.holder.getNumColumns()-1
        
#        print "derivative"
#        self.holder.runProcess(derivativeProcessor(magColumn))
#        derivColumn=self.holder.getNumColumns()-1


#        print "magnetic tracker"
#        simpleParticleTracker(self.holder,self.inMarker,self.outMarker)
        
#        print "integrate"
#        poolDirection=0.1
#        self.holder.runProcess(cleverSpeedProcessor(self.holder.getColumnFromName("forwards_mpsps"),self.holder.getColumnFromName("ori_x"),self.holder.getColumnFromName("legangle_degrees"),poolDirection))

        self.graphs=[]
#        self.columns=["roll_degrees","ori_x","ori_y","ori_z","legangle_degrees",magColumn,smoothColumn,"magSpeed","magPos","dbg1","dbg2",
#        "mag_x_global","mag_y_global","mag_z_global"]
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.SetSizer(self.sizer)
        self.Bind(wx.EVT_CLOSE,self.onDestroy)
        self.Bind(wx.EVT_KEY_DOWN, self.onKeyPress)

        wx.FutureCall(0, self.doProcessing)        
        self.Show(True)

    def doProcessing(self):
        print "process"
        
        self.holder.runProcess(magnitudeProcessor(self.holder.getColumnFromName(("mag_x","mag_y","mag_z"))))
        magColumn=self.holder.getNumColumns()-1

#        self.holder.runProcess(derivativeProcessor(self.holder.getColumnFromName("mag_x")))        
#        self.holder.runProcess(acceptFlatValuesProcessor(self.holder.getColumnFromName("roll_degrees"),5,self.holder.getColumnFromName("legangle_degrees"),magColumn))
#        flatColumn=self.holder.getNumColumns()-1


#        self.holder.runProcess(minMaxMidpointProcessor(self.holder.getColumnFromName("mag_x"),1.0/3.0))
#        self.holder.runProcess(minMaxMidpointProcessor(self.holder.getColumnFromName("mag_y"),1.0/3.0))
#        self.holder.runProcess(minMaxMidpointProcessor(self.holder.getColumnFromName("mag_z"),1.0/3.0))
#        self.holder.runProcess(magnitudeProcessor(self.holder.getColumnFromName(("mag_x_mid","mag_y_mid","mag_z_mid"))))
#        magColumn2=self.holder.getNumColumns()-1
        
        dtwTracker(self.holder,self.inMarker,self.outMarker,self.showDebug,self.leftPos)
        self.columns=["roll_degrees","ori_x","legangle_degrees","forwards_mpsps",magColumn,"magSpeed","magPos","dbg1","dbg2","dbg3"]
#        self.columns=["roll_degrees","ori_x","legangle_degrees","forwards_mpsps",magColumn,"mag_x_mid","mag_y_mid","mag_z_mid","sqrt(mag_x_mid^2+mag_y_mid^2+mag_z_mid^2)","magSpeed","magPos","dbg1","dbg2"]
#        self.columns=["roll_degrees","ori_x","legangle_degrees","mag_x","mag_y","mag_z",magColumn,"mag_x_mid","mag_y_mid","mag_z_mid","sqrt(mag_x_mid^2+mag_y_mid^2+mag_z_mid^2)","magSpeed","magPos","dbg1","dbg2"]
#        self.holder.runProcess(orientedMagneticProcessor((self.holder.getColumnFromName("ori_x"),self.holder.getColumnFromName("ori_y"),self.holder.getColumnFromName("ori_z")),(self.holder.getColumnFromName("mag_x"),self.holder.getColumnFromName("mag_y"),self.holder.getColumnFromName("mag_z")),self.leftPos,self.leftPos+500.0))
#        self.holder.runProcess(magnitudeProcessor(self.holder.getColumnFromName(("mag_x_global","mag_y_global"))))
#        magColumn3=self.holder.getNumColumns()-1
#        self.columns.append(magColumn3)
        
#        self.holder.runProcess(acceptFlatValuesProcessor(self.holder.getColumnFromName("roll_degrees"),5,self.holder.getColumnFromName("legangle_degrees"),magColumn3))       
 #       self.columns.append(self.holder.getNumColumns()-1)
        self.player=NetSender(self.holder,self.columns,self)                
 
        wx.FutureCall(0, self.onLoadGraphs)        
    
        
    def onLoadGraphs(self):
        self.graphs=[]
        
#        self.columns=["roll_degrees","flipped","legangle_degrees","forwards_mpsps","forwards_mpsps_speed","forwards_mpsps_pos","ori_x","ori_y","ori_z",magColumn,"magPos","dbg1"]
        for c in self.columns:
            if type(c)==type(""):
                columnName=c
                c=self.holder.getColumnFromName(columnName)
            else:
                columnName=self.holder.getColumnName(c)
            self.graphs.append(SimpleGraph(self,self.holder,c))
            if columnName.endswith("flipped"):
                self.graphs[-1].setFixedVerticalRange((-1.0,1.0))
            elif columnName.endswith("_degrees"):
                self.graphs[-1].setFixedVerticalRange((-90.0,90.0))
            elif columnName.endswith("_mps") or columnName.endswith("_mpsps") or columnName.startswith("lin_"):
                self.graphs[-1].setFixedVerticalRange((-4.0,4.0))
            elif columnName.endswith("_integrated"):
                self.graphs[-1].setFixedVerticalRange((None,4.0))
#            elif columnName.startswith("ori_"):
#                self.graphs[-1].setAngle()
        self.graphs[-1].showTimeAnnotations(True)
        for graph in self.graphs:
            self.sizer.Add(graph,proportion=0,flag=wx.EXPAND,border=0)
            graph.Bind(wx.EVT_KEY_DOWN, self.onKeyPress)
        self.Layout()
        self.layoutGraphs()
        self.updateGraphs()
        self.updateSelection()
    
        
    def onKeyPress(self,evt):
        code=evt.GetKeyCode()
        movementMultiplier=0.05
        if evt.ControlDown():
            movementMultiplier=0.25
        if evt.ShiftDown():
            movementMultiplier*=0.1
        if code==wx.WXK_HOME:
            self.leftPos=self.holder.getMinTime()
        elif code==ord('I'):
            self.inMarker=self.leftPos
            self.updateSelection()
        elif code==ord('O'):
            self.outMarker=self.leftPos+self.rangeLength
            self.updateSelection()
        elif code==wx.WXK_END:
            self.leftPos=self.holder.getMaxTime()-self.rangeLength
        elif code==wx.WXK_RIGHT:
            self.leftPos+=self.rangeLength*movementMultiplier            
        elif code==wx.WXK_LEFT:
            self.leftPos-=self.rangeLength*movementMultiplier
        elif code==wx.WXK_TAB:
            if evt.ControlDown():
                # jump to marker on next screen
                range=self.holder.getMarkerRange((self.leftPos+self.rangeLength,self.holder.getMaxTime()))
            else:
                # jump to next marker
                range=self.holder.getMarkerRange((self.leftPos+0.01,self.holder.getMaxTime()))
            if len(range)>0:
                self.leftPos=range[0][0]
        elif code==wx.WXK_ADD or code==ord('+'):
            self.rangeLength*=0.5
            if self.rangeLength<1.0:
                self.rangeLength=1.0
        elif code==wx.WXK_SUBTRACT or code==ord('-'):
            self.rangeLength*=2.0
            if self.rangeLength>160.0:
                self.rangeLength=160.0
        elif code==ord('P'):
            # start or stop playback
            if self.player.isPlaying()==False:
                self.player.startPlaying(self.leftPos)
                print "start"
            else:
                print "stop"
                self.player.stopPlaying()
        elif code==ord('Q'):
            self.player.shutdown()
            self.saveSettings()
            self.Destroy()
        if self.leftPos<self.holder.getMinTime():
            self.leftPos=self.holder.getMinTime()
        if self.leftPos>self.holder.getMaxTime():
            self.leftPos=self.holder.getMaxTime()
        self.updateGraphs()
            
    def updateGraphs(self):        
        for graph in self.graphs:
            graph.setRange((self.leftPos,self.leftPos+self.rangeLength))

    def updateSelection(self):        
        for graph in self.graphs:
            graph.setSelection(self.inMarker,self.outMarker)
            
    def showTempMarkerOnGraphs(self,x):
        for graph in self.graphs:
            graph.showTempMarker(x)
            
    def layoutGraphs(self):
        for graph in self.graphs:
            sizerItem=self.sizer.GetItem(graph)
            if graph.isMinimized:
                sizerItem.SetProportion(0)
            else:
                sizerItem.SetProportion(1)    
        self.Layout()                
            
    def onPlayTime(self,time):
        self.leftPos=time
        self.updateGraphs()

    def onDestroy(self,evt):
        self.player.shutdown()
        evt.Skip()
        
    def saveSettings(self):
        config = ConfigParser()
        filename=os.path.join(os.path.dirname(__file__),"graphlog.ini")               
        try:
            with open(filename) as configfile:
                config.read(filename)
        except:
            print "couldn't open config file"
        
        sectionName=os.path.abspath(self.sourceFile)        
        if not config.has_section(sectionName):
            config.add_section(sectionName)
        config.set(sectionName, 'leftPos', self.leftPos)
        config.set(sectionName, 'rangeLength', self.rangeLength)
        if self.inMarker==None:
            config.set(sectionName, 'inMarker', 0.0)
        else:
            config.set(sectionName, 'inMarker', self.inMarker)
        if self.outMarker==None:
            config.set(sectionName, 'outMarker', 0.0)
        else:
            config.set(sectionName, 'outMarker', self.outMarker)

        # Writing our configuration file to 'example.cfg'
        with open(filename, 'wb') as configfile:
            config.write(configfile)
            
    def loadSettings(self):
        config = ConfigParser()
        filename=os.path.join(os.path.dirname(__file__),"graphlog.ini")               
        try:
            with open(filename) as configfile:
                config.read(filename)
        except:
            print "couldn't open config file"
        sectionName=os.path.abspath(self.sourceFile)        
        if config.has_section(sectionName):
            try:
                self.leftPos=config.getfloat(sectionName,'leftPos')
                self.rangeLength=config.getfloat(sectionName,'rangeLength')
                self.inMarker=config.getfloat(sectionName,'inMarker')
                if self.inMarker==0:
                    self.inMarker=None
                self.outMarker=config.getfloat(sectionName,'outMarker')
                if self.outMarker==0:
                    self.outMarker=None
            except:
                print "error reading from config section"
        
            
            
def startup(filename,showDebug=False):            
    app = wx.App(False)    
    frame = CSVGrapher(None, filename,showDebug)
    app.MainLoop()
            
if len(sys.argv)>1:
    if len(sys.argv)==3:
        startup(sys.argv[1],True)
    else:
        if sys.argv[1]=='-h' or sys.argv[1]=='-?':  
            print "Usage:\n     graphlog.py filename.csv\n"        
        startup(sys.argv[1])
else:
    startup(None)
