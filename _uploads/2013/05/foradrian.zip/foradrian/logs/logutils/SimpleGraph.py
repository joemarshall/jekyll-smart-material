from BufferedWindow import *

import time
import math

class SimpleGraph(BufferedWindow):
    def __init__(self, parent,dataFile,  dataColumn,**kwargs):
        ## Any data the Draw() function needs must be initialized before
        ## calling BufferedWindow.__init__, as it will call the Draw
        ## function.        
        self.fixedVerticalRange=None
        self.timeRange=(dataFile.getMinTime(),dataFile.getMinTime()+10.0)
        self.dataFile=dataFile
        self.dataColumn=dataColumn
        self.columnName=dataFile.getColumnName(dataColumn)        
        self.minVal=0
        self.maxVal=0
        self.displayBuf=None
        self.displayTimedMarkers=False
        self.outSelection=None
        self.inSelection=None
        self.isAngle=False
        self.theOwner=parent
        self.isMinimized=False
        self.tempMarker=None
        
        BufferedWindow.__init__(self, parent,name=dataFile.getName(), **kwargs)

        if self.dataColumn==-1:
            self.SetMinSize(wx.Size(1,1))
            self.isMinimized=True
        else:        
            self.SetMinSize(wx.Size(25,25))
        self.Bind(wx.EVT_MOTION, self.onMouseMotion)
        self.Bind(wx.EVT_RIGHT_UP,self.onRightClick)
        self.Bind(wx.EVT_LEFT_DOWN,self.onLeftClick)
        
    def getTimeString(self,theTime):
        str= time.strftime("%H:%M:%S.", time.localtime(theTime))
        numberMs=(theTime*1000)%1000
        str+="%03d"%numberMs
        return str
        
    def setRange(self,range):
        if self.timeRange!=range:
            self.timeRange=range
            self.LazyUpdateDrawing()
        
    def setSelection(self,inMarker,outMarker):
        self.inSelection=inMarker
        self.outSelection=outMarker
        self.LazyUpdateDrawing()
        
    def setFixedVerticalRange(self,vrange):
        self.fixedVerticalRange=vrange
        
    def setAngle(self,radians=True):
        self.isAngle=True
        if radians:
            self.fixedVerticalRange=(-math.pi,math.pi)
        else:
            self.fixedVerticalRange=(-180.0,180.0)
            

    def onRightClick(self,evt):
        if self.dataColumn==-1:
            self.isMinimized=True
            return
        self.isMinimized=not self.isMinimized
        self.theOwner.layoutGraphs()

    def onLeftClick(self,evt):
        if self.dataColumn==-1:
            self.isMinimized=True
            return
        self.isMinimized=not self.isMinimized
        x,y=evt.GetPosition()
        self.theOwner.showTempMarkerOnGraphs(x)        

    def showTempMarker(self,x):
        self.tempMarker=x
        self.LazyUpdateDrawing()
        
    def minimized(self):
        return self.isMinimized

            
    def onMouseMotion(self,evt):
        x,y=evt.GetPosition()
        w,h=self.GetClientSizeTuple()
        
        val=None
        if self.displayBuf!=None:
            displayedTimeScale=self.dataEndTime-self.dataStartTime
            requestedTimeScale=self.timeRange[1]-self.timeRange[0]
            horizontalOffset=w*(displayedTimeScale/requestedTimeScale)/float(len(self.displayBuf))
            valPos=x/horizontalOffset
            if valPos<len(self.displayBuf):
                val=self.displayBuf[int(valPos)]

        y*=(self.minVal-self.maxVal)
        y/=float(h)
        y+=self.maxVal
        
        x=x*(self.timeRange[1]-self.timeRange[0])
        x=x/w
        x+=self.timeRange[0]

                
        if val!=None:
            str="%s\n%f (value)\n%f (mouse)\n"%(self.getTimeString(x),val,y)
        else:
            str="%s\n%f (mouse)\n"%(self.getTimeString(x),y)
        
        self.SetToolTipString(str)
        evt.Skip()

    def showTimeAnnotations(self,show):
        self.displayTimedMarkers=show
        
    def Draw(self, dc):
        w,h=self.GetClientSizeTuple()
        dc.SetBackground( wx.Brush("White") )
        dc.Clear() 
        dc.SetPen(wx.Pen((140,140,140)))
        dc.DrawRectangle(0,0,w-1,h-1)
        dc.SetPen(wx.Pen((0,0,0)))
        
        
        if self.dataColumn==-1:
            return
        self.displayBuf,self.dataStartTime,self.dataEndTime=self.dataFile.getRange(self.timeRange,self.dataColumn)
        numVals=len(self.displayBuf)
        autoMinMax=False
        if self.fixedVerticalRange!=None:
            self.minVal,self.maxVal=self.fixedVerticalRange
            if self.minVal==None:
                # fixed height (maxVal), but offset based on first value
                self.minVal=self.displayBuf[0]-self.maxVal*0.5
                self.maxVal=self.displayBuf[0]+self.maxVal*0.5
        else:
            autoMinMax=True
            

        if self.inSelection!=None and self.inSelection<self.timeRange[1] and self.outSelection!=None and self.outSelection>self.timeRange[0] and self.inSelection<self.outSelection:
            xPos1=(self.inSelection - self.timeRange[0])*(w / (self.timeRange[1]-self.timeRange[0]))
            xPos1=max(0,xPos1)
            xPos2=(self.outSelection - self.timeRange[0])*(w / (self.timeRange[1]-self.timeRange[0]))
            xPos2=min(w,xPos2)
            dc.SetPen(wx.NullPen)
            dc.SetBrush(wx.Brush(wx.Colour(180,180,180)))
            dc.DrawRectangle(xPos1,0,xPos2-xPos1,h)

        if self.tempMarker!=None:
            dc.DrawLine(self.tempMarker,0,self.tempMarker,h)
            self.tempMarker=None
            
            
        dc.DrawText(self.columnName,2,0)
        if not self.isMinimized:
            str1=self.getTimeString(self.timeRange[0])
            str2=self.getTimeString(self.timeRange[1])
            extent1=dc.GetTextExtent(str1+str2)
            extent2=dc.GetTextExtent(str2)
            dc.DrawText(str1,2,h-extent1[1])
            dc.DrawText(str2,w-extent2[0]-2,h-extent1[1])
        

        if len(self.displayBuf)>0:
            displayedTimeScale=self.dataEndTime-self.dataStartTime
            requestedTimeScale=self.timeRange[1]-self.timeRange[0]
                        
            horizontalOffset=w*(displayedTimeScale/requestedTimeScale)/float(numVals)
            drawW=int(w*(displayedTimeScale/requestedTimeScale))
            offsetIntoBufferPerPixel=1.0/horizontalOffset
            
            if autoMinMax:
                minVal=self.displayBuf[0]
                maxVal=self.displayBuf[0]
                valuePos=0
                for x in range(1,drawW):
                    valuePos+=offsetIntoBufferPerPixel
                    value=self.displayBuf[int(valuePos)]                
                    if value<minVal: minVal=value
                    if value>maxVal: maxVal=value
                self.maxVal=maxVal
                self.minVal=minVal
                    
            
            if self.isAngle:
                verticalOffset=-self.maxVal
                verticalMultiplier=h/(self.minVal-self.maxVal)
                verticalMultiplier*=2
                
                zeroLine=verticalOffset*verticalMultiplier
                dc.DrawLine(0,zeroLine,w,zeroLine)
                lines=[]
                pens=[]
                greyPen=wx.Pen((140,140,140))
                blackPen=wx.Pen((0,0,0))
                ox=0
                oy=(self.displayBuf[0]+verticalOffset)*verticalMultiplier
                if oy>h: 
                    oy=h-oy
                    curPen=greyPen
                else:
                    curPen=blackPen
                valuePos=0.0
                for x in range(1,drawW):
                    valuePos+=offsetIntoBufferPerPixel
                    value=self.displayBuf[int(valuePos)]
                    y=(value +verticalOffset)*verticalMultiplier
                    if y>h:
                        y=h-y+h
                        curPen=greyPen
                    else:
                        curPen=blackPen
                    lines.append((ox,oy,x,y))
                    pens.append(curPen)
                    ox=x
                    oy=y
                dc.DrawLineList(lines,pens)
            else:
                verticalOffset=-self.maxVal
                if self.minVal!=self.maxVal:
                    verticalMultiplier=h/(self.minVal-self.maxVal)
                else:
                    verticalMultiplier=h*0.5
                
                zeroLine=verticalOffset*verticalMultiplier
                dc.DrawLine(0,zeroLine,w,zeroLine)
                lines=[]
                ox=0
                oy=(self.displayBuf[0]+verticalOffset)*verticalMultiplier
                valuePos=0
                for x in range(1,drawW):
                    valuePos+=offsetIntoBufferPerPixel
                    value=self.displayBuf[int(valuePos)]
                    y=(value +verticalOffset)*verticalMultiplier
                    lines.append((ox,oy,x,y))
                    ox=x
                    oy=y
                dc.DrawLineList(lines)
            markers=self.dataFile.getMarkerRange(self.timeRange)
            for marker in markers:
                if len(marker)==4:
                    if self.displayTimedMarkers:
                        (time1,colour,data,time2) =marker
                        pen = wx.Pen(colour)
                        dc.SetPen(pen)
                        xPos1=(time1 - self.timeRange[0])*(w / (self.timeRange[1]-self.timeRange[0]))
                        xPos2=(time2 - self.timeRange[0])*(w / (self.timeRange[1]-self.timeRange[0]))
    #                    dc.DrawLine(xPos1,h*0.5,xPos2,h*0.5)
                        extent=dc.GetTextExtent(str(data))
                        dc.DrawLabel(str(data),wx.Rect(xPos1,0,xPos2-xPos1,h),wx.ALIGN_CENTER)
                elif len(marker)==3:
                    (time,colour,data) =marker
                    pen = wx.Pen(colour)
                    dc.SetPen(pen)
                    xPos=(time - self.timeRange[0])*(w / (self.timeRange[1]-self.timeRange[0]))
                    dc.DrawLine(xPos,0,xPos,h)                
