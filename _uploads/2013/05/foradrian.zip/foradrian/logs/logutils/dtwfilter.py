# dynamic time warping - 
#
# downsample the pool profile to 250 samples ie. 10ths of a metre
#
#
# each time we get a new flat point (at .2th of a second max), then
# we need to score all the possible points on the pool profile against the new point
# to create a new column in our DTW matrix
# 
# we can assume: 1)it can only move a certain distance between points (based on speed, ?and average speed variation?)
#                2)the absolute position can only be within a certain range (based on overall speed)
#                3)we only go forwards
#                this rules out a bunch of points
#
# so need to calculate <250 scores for each new sample (based on min/max possible positions)
# - scores based on the difference between flat points and the difference in the profile?
#   or something cunninger?
#
# to score each point on the column, S(flatPt,poolPos) = min for all X[(S(flatPt-1,x) + distFn(x,dt,deltaFlatPts,poolPos))]
# nb. this is potentially o(n^2) in pool profile samples (ie. 
# each time step which is a pain, but locality constraints above should hopefully make it practical
#                
# at each point, the estimated position is the minimum of the matrix last column
#
# nb. do we want to score for some kind of flatness / mean angle and store that in each position too, used for the scoring?

# use only flat values
# so only track each time we are flat, anything more is overkill as
# we have no extra information
#
import wx

from collections import deque
import random
import bisect
import time
import math
from processors import averageBuffer,slopeBuffer

class dtwTracker:
    def __init__(self,holder,selectionIn,selectionOut,showDebugInfo,leftPos):
        self.holder=holder
        if selectionIn==None or selectionOut==None:
            return
        self.selectionIn=selectionIn
        self.selectionOut=selectionOut
        self.magneticDensityShape=[]# length going one way
        self.magneticDensityShapeBack=[] # length going other way
        self.magneticDensityColumn=holder.getColumnFromName("sqrt(mag_x^2+mag_y^2+mag_z^2)")
        values,minTime,maxTime=holder.getRange((selectionIn,selectionOut),self.magneticDensityColumn)
        dirValues,minTime,maxTime=holder.getRange((selectionIn,selectionOut),holder.getColumnFromName("ori_x"))
        angleValues,minTime,maxTime=holder.getRange((selectionIn,selectionOut),holder.getColumnFromName("legangle_degrees"))
        # profile selection is an out and back swim of the pool - as the profiles may be different in
        # each direction

        doubleProfile=False
        if doubleProfile:
            self.poolDirection=dirValues[int(len(values)/4)]    
            # split it at the turnaround
            lastDir=0
            turnaroundPoint=len(values)/2
            while turnaroundPoint>=0 and turnaroundPoint<len(values):
                direction=dirValues[turnaroundPoint]
                directionDiff=abs(self.poolDirection-direction)
                if directionDiff>math.pi:
                    directionDiff=2*math.pi-directionDiff
                if directionDiff<math.pi/2:
                    # forwards direction, we are before the split
                    turnaroundPoint+=1
                    lastDir=1
                else:
                    #backwards direction, we are after the split
                    turnaroundPoint-=1
                    if lastDir==1:
                        break
                    lastDir=-1
                    
            firstLengthEnd=turnaroundPoint
            while firstLengthEnd>=0 and abs(angleValues[firstLengthEnd])>40.0:
                firstLengthEnd-=1
                    
            secondLengthStart=turnaroundPoint
            while secondLengthStart<len(values) and abs(angleValues[secondLengthStart])>40.0:
                secondLengthStart+=1
                
            for c in range(0,firstLengthEnd):
                # find first length            
                self.magneticDensityShape.append(values[c])

            for c in range(turnaroundPoint,len(values)):
                # find first length            
                self.magneticDensityShapeBack.append(values[c])
        else:
            self.poolDirection=dirValues[int(len(values)/2)]    
            for val in values:
                # find first length            
                self.magneticDensityShape.append(val)
            for val in reversed(self.magneticDensityShape):
                self.magneticDensityShapeBack.append(val)
        
    
        # smoothing (non-biased so we don't have a shift)
        smoothingLen=100
                
        self.smoothedMagneticDensity=self.unbiasedSmooth(self.magneticDensityShape,smoothingLen)
        self.smoothedMagneticDensityBack=self.unbiasedSmooth(self.magneticDensityShapeBack,smoothingLen)            
            
        self.downsampledMagneticDensity=self.downSample(self.smoothedMagneticDensity,250)
        self.downsampledMagneticDensityBack=self.downSample(self.smoothedMagneticDensityBack,250)
            
        if showDebugInfo:
            startProcessingPos=leftPos-5.0
        else:
            startProcessingPos=0.0            
        magProcess=self.dynamicTimeWarpProcessor(self.downsampledMagneticDensity,self.downsampledMagneticDensityBack,self.poolDirection,self.magneticDensityColumn,holder.getColumnFromName("forwards_mpsps"),holder.getColumnFromName("legangle_degrees"),holder.getColumnFromName("ori_x"),holder.getColumnFromName("roll_degrees"),startProcessingPos,leftPos+10000.0,showDebugInfo)
        self.holder.runProcess(magProcess)

    def downSample(self,buffer,newlen):
        offset=0.0
        step=float(len(buffer))/float(newlen)
        retVal=[]
        for c in range(0,int(newlen)):
            retVal.append(buffer[int(offset)])
            offset+=step
        return retVal
    
        
    def unbiasedSmooth(self,buffer,smoothingLen):
        # first, add half as many values to the buffer
        # then for each sample we take mean of the buffer
        # and add another sample
        result=[]
        smoother=deque(maxlen=smoothingLen)
        for c in buffer[0:smoothingLen/2]:
            smoother.append(c)
        for c in buffer[smoothingLen/2:]:
            result.append(self.mean(smoother))
            smoother.append(c)
        for c in range(0,smoothingLen/2):
            result.append(self.mean(smoother))
            smoother.popleft()
        return result
    
        
    def mean(self,buf):
        sum=0.0
        count=0.0
        for c in buf:
            sum+=c
            count+=1.0
        if count==0.0:
            return 0.0
        else:
            return sum/count
        
        
    class dynamicTimeWarpProcessor:
        def __init__(self,poolProfile,poolProfileBack,poolDirection,magneticCol,accelCol,legAngleCol,directionCol,rollCol,startEverything,stopEverything,showDebugInfo):
            self.poolProfile,self.poolProfileBack,self.poolDirection,self.magneticCol,self.accelCol,self.legAngleCol,self.directionCol,self.rollCol=(poolProfile,poolProfileBack,poolDirection,magneticCol,accelCol,legAngleCol,directionCol,rollCol)            
            self.startEverything=startEverything
            self.stopEverything=stopEverything

            self.lastVelocity=0       
            self.lastTime=None
            self.timeColumn=0
            self.timeMultiplier=1
            self.accelHistory=deque(maxlen=1000)
            self.directionHistory=deque(maxlen=1000)
            self.legAngleHistory=deque(maxlen=1000)
            self.dtHistory=deque(maxlen=1000)
            self.stopped=True
            self.poolPos=0.0
            
            self.curLengthStart=0.0
            self.lastRoll=0.0
            self.lastRoll2=0.0
            self.lastMagnetic=0.0
            
            self.swimmingBack=False
            
            self.dtwMatrix=[]
            self.dtwHistory=[]
            
            self.lastUpdateTime=0.0
            self.magPositionEstimate=0.0
            self.magVelocityEstimate=0.0
            self.dbgValue=0.0
            if showDebugInfo:
                self.dlg=DTWDebugWindow(self.poolProfile,self.poolProfileBack)
                self.dlg.Show()
            else:
                self.dlg=None
            
            
        def initHolder(self,holder):
            nanoCol=holder.getColumnFromName("nanotime")
            if nanoCol!=-1:
                self.timeColumn=nanoCol
                self.timeMultiplier=1.0/1000000000.0
            
        def processValues(self,values):                
            thisTime=float(values[self.timeColumn])*self.timeMultiplier
            if values[0]<self.startEverything or values[0]>self.stopEverything:
                values.append(0.0)
                values.append(0.0)
                values.append(0.0)
                values.append(0.0)
                values.append(0.0)
                return values

            curAccel=values[self.accelCol]
            curDirection=values[self.directionCol]
            curLegAngle=values[self.legAngleCol]
            curMagnetic=values[self.magneticCol]
            curRoll=values[self.rollCol]
            if self.lastTime==None:
                self.lastVelocity=0
            else:
                diffTime=thisTime-self.lastTime
                if curLegAngle>40:  
                    # stopped - assume zero speed
                    self.lastVelocity=0
                    self.poolPos=0
                    self.magPositionEstimate=0
                    if not self.stopped:
                        self.legAngleHistory.clear()
                        self.directionHistory.clear()
                        self.accelHistory.clear()
                        self.dtHistory.clear()
                    self.stopped=True
                    self.legAngleHistory.append(curLegAngle)
                    self.directionHistory.append(curDirection)
                    self.accelHistory.append(curAccel)
                    self.dtHistory.append(diffTime)
                else:
                    # swimming - integrate speed
                    if self.stopped:
                        # just started a length - check if there is any previous
                        # acceleration which we need to take account of
                        # since either: moment of turn (if we were swimming < 1000 data points ago)
                        #            or first point of verticality where we were
                        #            roughly pointing poolwards (if we started from the wall)
                        # start of a length:
                        directionDiff=abs(self.poolDirection-curDirection)
                        if directionDiff>math.pi:
                            directionDiff=2*math.pi-directionDiff
                        if directionDiff<math.pi/2:
                            # going in pool direction
                            self.swimmingBack=False
                        else:
                            # going back
                            self.swimmingBack=True                
                        self.resetDTWMatrix()
                        self.lastUpdateTime=thisTime
                        startedPos=len(self.legAngleHistory)
#                        if len(self.legAngleHistory)<1000:
                        # nb: if we want to handle turns and starts differently, could use the if above
                        # after a turn
                        # look for a turn or start- where pool direction sharply changes                        
                        # and also go back until leg angle stops rising
                        
                        lastLegAngle=curLegAngle
                        foundStart=False
                        curPos=len(self.legAngleHistory)-1
                        while (not foundStart) and curPos>0:
                            curPos-=1
                            thisAngle=self.legAngleHistory[curPos]
                            thisDirection=self.directionHistory[curPos]
                            if abs(thisAngle)<abs(lastLegAngle):
                                foundStart=True
                            directionDiff=abs(thisDirection-curDirection)
                            if directionDiff>math.pi:
                                directionDiff=2.0*math.pi - directionDiff
                            if abs(thisDirection - curDirection)>math.pi*0.25:
                                foundStart=True
                            if curPos>0:
                                startedPos=curPos
                        self.lastVelocity=0
                        # this code makes the assumption that we never go backwards during a start!
                        totalDTHistory=0
                        for c in range(startedPos,len(self.legAngleHistory)):
                            self.lastVelocity=self.lastVelocity+ (self.accelHistory[c]*self.dtHistory[c])
                            totalDTHistory+=self.dtHistory[c]
#                            self.poolPos=max(self.lastVelocity*self.dtHistory[c]+self.poolPos,0)
                        self.lastVelocity=max(self.lastVelocity,0)
                        if startedPos<len(self.legAngleHistory):
                            self.stepDTWMatrix(curMagnetic,0.0,self.lastVelocity)
                            self.curLengthStart=thisTime
                        else:
                            self.stepDTWMatrix(curMagnetic,0.0,0.0)
                            self.curLengthStart=thisTime                        
                        self.velocityChange=0.0                            
                        #print len(self.legAngleHistory)-startedPos
                        self.stopped=False

                    # normal pool update - never go backwards
                    self.lastVelocity= max(self.lastVelocity+ (curAccel*diffTime),0)
                    self.poolPos+=self.lastVelocity*diffTime
                    self.velocityChange=self.velocityChange+curAccel*diffTime
                    if abs(curRoll)<10.0 and abs(self.lastRoll2)>abs(self.lastRoll) and abs(curRoll)>abs(self.lastRoll):
                        # we are flat and at a minima of roll - magnetic history should be low noise, so add this point to the reference set
                        # keep this reference set sparse[ish] so that when we stretch it to match, it is
                        # somewhat quicker
                        if thisTime-self.lastUpdateTime>0.2:
                            self.lastUpdateTime=self.lastTime
                            self.stepDTWMatrix(self.lastMagnetic,self.lastTime-self.curLengthStart,self.velocityChange)
                            self.velocityChange=0.0
                    if len(self.dtwHistory)>2 and thisTime-self.curLengthStart>2.0+self.dtwHistory[2][1]:
                        self.poolPos=self.magPositionEstimate*0.005 + 0.995*self.poolPos
                        self.lastVelocity=self.lastVelocity*0.99 + 0.01*self.magVelocityEstimate
                    # update magnetic position based on current magnetic pace estimate
                    self.magPositionEstimate=min(25.0,self.magPositionEstimate+self.magVelocityEstimate*diffTime)
                   
            self.lastRoll2=self.lastRoll
            self.lastRoll=curRoll
            values.append(self.lastVelocity)
            values.append(self.poolPos)

            values.append(self.magPositionEstimate)
            values.append(self.magVelocityEstimate)
            values.append(self.dbgValue)
            self.lastTime=thisTime
            self.lastMagnetic=curMagnetic
            return values
            
        def resetDTWMatrix(self):
            self.dtwMatrix=[]
            self.dtwHistory=[]
            self.magPositionEstimate=0.0
            self.magVelocityEstimate=0.0
            
        def stepDTWMatrix(self,magneticValue,timeSinceStart,velocityChangeSinceLast,doInterpolation=True):
            if len(self.dtwHistory)>0 and doInterpolation:
                lastMagValue,lastTime,lastOutputPosition=self.dtwHistory[-1]            
                dt= timeSinceStart-lastTime
                if dt>=0.2:
                    # if we've been much more than 0.2 seconds then do multiple steps
                    # with linear interpolation between the mag values
                    # to avoid missing minima/maxima in the profile
#                    print "*",lastMagValue,magneticValue
                    dMag=magneticValue-lastMagValue
                    numSteps=int(dt/0.2)
                    numSteps=max(numSteps,2)
                    stepTime=dt/float(numSteps)
                    stepVal=dMag/float(numSteps)
                    velocityChange=velocityChangeSinceLast/float(numSteps)
                    curVal=lastMagValue+stepVal
                    curTime=lastTime+stepTime
                    # do linear interpolation of chosen result values and choose the result value
                    # at the last position here, rather than just
                    # taking the last position - maybe that will reduce noise
                    # nb. do we need to check for outliers also?
                    
                    sumXX=0
                    sumXY=0
                    sumY=0
                    sumX=0
                    
                    for c in range(numSteps):
                        self.stepDTWMatrix(curVal,curTime,velocityChange,False)
                        result=self.magPositionEstimate
                        
                        sumXX+=curTime*curTime
                        sumXY+=curTime*result
                        sumY+=result
                        sumX+=curTime
                        
                        curVal+=stepVal
                        curTime+=stepTime

                    slope=(numSteps*sumXY -sumX*sumY)/(numSteps*sumXX - sumX*sumX)
                    intercept=(sumY-slope*sumX)/numSteps
                    
                    self.magPositionEstimate= timeSinceStart * slope +intercept
                        
                    return
            # min and max speeds in metres per second and pool length
            
            MIN_SPEED=0.25
            MAX_SPEED=3.0
            POOL_LENGTH=25.0
            if self.swimmingBack:
                profile=self.poolProfileBack
            else:
                profile=self.poolProfile
            PROFILE_STEPS=len(profile)
            PROFILE_STEPS_PER_METRE=(float(PROFILE_STEPS)/POOL_LENGTH)                       
            
            minProfileStep = int(math.floor(timeSinceStart*MIN_SPEED*PROFILE_STEPS_PER_METRE))
            maxProfileStep = int(math.ceil(timeSinceStart*MAX_SPEED*PROFILE_STEPS_PER_METRE))
            maxProfileStep=min(maxProfileStep,PROFILE_STEPS-1)
            minProfileStep=max(minProfileStep,0)
            maxProfileStep=max(maxProfileStep,minProfileStep+1)
            minPos=0
            
 #           print "woo",timeSinceStart,magneticValue
            if len(self.dtwMatrix)==0:
                # first magnetic position - just use timeSinceStart to calculate which entries are possible
                # and give them all a cost of 0, and infinity to the rest
                if  minProfileStep<maxProfileStep:
                    self.dtwMatrix.append([None]*PROFILE_STEPS)
                    if timeSinceStart>0:
                        for c in range(minProfileStep,maxProfileStep):
                            self.dtwMatrix[-1][c]=(1.0,0.0,float(c)/(timeSinceStart*PROFILE_STEPS_PER_METRE))
#                            self.dtwMatrix[-1][c]=(0,float(c)/(timeSinceStart*PROFILE_STEPS_PER_METRE))
                    else:
                        for c in range(minProfileStep,maxProfileStep):
                            self.dtwMatrix[-1][c]=(1.0,0.0,0.0)
            else:
                lastMagValue,lastTime,lastOutputPosition=self.dtwHistory[-1]
                dt= timeSinceStart-lastTime
                dMag = magneticValue-lastMagValue
                minProfileMovement= int(math.floor(dt*MIN_SPEED*PROFILE_STEPS_PER_METRE))
                maxProfileMovement= int(math.ceil(dt*MAX_SPEED*PROFILE_STEPS_PER_METRE))
                maxProfileMovement=min(maxProfileMovement,PROFILE_STEPS-1)
                minProfileMovement=max(minProfileMovement,0)#
                if dt>0.0:
                    # how many steps we can stay still (at minimum speed)
                    maxTimeStill=math.ceil(1.0/(dt*MIN_SPEED*PROFILE_STEPS_PER_METRE))
                else:
                    maxTimeStill=5
                #print "dt=%f,minProfileMovement=%d,maxProfileMovement=%d"%(dt,minProfileMovement,maxProfileMovement)
                # always allow 1 step per time period at least as otherwise
                # we could get stuck
                maxProfileMovement=max(maxProfileMovement,minProfileMovement+1)
                
                self.dtwMatrix.append([None]*PROFILE_STEPS)
                for c in range(minProfileStep,maxProfileStep):
                    # could we have stepped to here, and if so, where from
                    # cost is done by gradient of the step
                    minScore=None
                    for d in range(c-maxProfileMovement,(c-minProfileMovement)+1):
                        oldVal=self.dtwMatrix[-2][d]
                        if oldVal!=None:
                            oldCost,oldTimeStill,oldSlope=oldVal
                            thisSlope=(c-d)/(dt*PROFILE_STEPS_PER_METRE)
                            expectedSlope=velocityChangeSinceLast+oldSlope
                            dVelocity=(expectedSlope-thisSlope)                            
                            thisSlope=0.9*oldSlope+thisSlope*0.1
                            dProfile=profile[c]-profile[d]
                            error=dMag-dProfile
                            if c==d:
                                timeStill=oldTimeStill+1
                            else:
                                timeStill=0
                            if timeStill>maxTimeStill:
                                continue
                            dVelocity=max(abs(dVelocity),0.5)
#                            dVelocity=1.0+max(abs(dVelocity)-2.0*dt,0)
                            cost=error*error*dVelocity*dVelocity
                            cost= oldCost+cost
                            if minScore==None or cost<minScore[0]:
                                minScore=(cost,timeStill,thisSlope)
                                minPos=d
                    self.dtwMatrix[-1][c]=minScore
 #                   print minPos,c
 #                   print minScore[0],
 #           print ""
            if len(self.dtwMatrix)>0:
                minVal=None
                minPos=0
                for c in range(0,PROFILE_STEPS):
                    val=self.dtwMatrix[-1][c]
                    #print val,
                    if val!=None and (val[0]<minVal or minVal==None):
                        minVal=val[0]
                        minPos=c
                #print "\n",minPos
                if minPos!=None and minPos>=0.0:
                    self.magPositionEstimate=float(minPos) /PROFILE_STEPS_PER_METRE
                    self.dbgValue=profile[minPos]
                    # estimate speed as being equal to estimated lap pace
                    # will slightly overestimate normally
                    # and may slightly under or overestimate if speed changes during
                    # a lap
                    if timeSinceStart>0.0:
                        self.magVelocityEstimate=float(minPos)/(PROFILE_STEPS_PER_METRE*timeSinceStart)
                    else:
                        self.magVelocityEstimate=0.0
#                str=""
#                for c in range(0,PROFILE_STEPS):
#                    if self.dtwMatrix[-1][c]==None:
#                        str+=","
#                    else:
#                        str+="%2.0f,"%(self.dtwMatrix[-1][c][0])
                #print str
                
           #     bestPos= int(4.98 * timeSinceStart)
           #     if bestPos<250:
           #         print magneticValue,timeSinceStart,self.dtwMatrix[-1][bestPos]
            if self.dlg!=None:
                self.dlg.UpdateMatrix(self.dtwMatrix,magneticValue,minPos,self.swimmingBack,timeSinceStart)
            self.dtwHistory.append((magneticValue,timeSinceStart,minPos))
            
        def newColumnNames(self,names):
            names.append("magSpeed")
            names.append("magPos")
            names.append("dbg1")
            names.append("dbg2")
            names.append("dbg3")
            return names
            

    
class DTWDebugWindow(wx.Frame):
    def __init__(self,poolProfile,poolProfileBack,**kwargs):
        wx.Frame.__init__(self, None, title="DTW Debug info")
        self.SetWindowStyle(self.GetWindowStyle()|wx.CLIP_CHILDREN)
        
        self.sizer = wx.FlexGridSizer(2,2,5,5)
        self.sizer.AddGrowableCol(0,1)
        self.sizer.AddGrowableRow(0,1)
        self.map1=MatrixHeatMap(self)
        self.sideGraph=SideGraph(self,poolProfile)
        self.bottomGraph=BottomGraph(self)
        self.sizer.Add(self.map1,flag=wx.EXPAND,border=0)
        self.sizer.Add(self.sideGraph,flag=wx.EXPAND,border=0)
        self.sizer.Add(self.bottomGraph,flag=wx.EXPAND,border=0)
        self.SetSizer(self.sizer)        
        self.Layout()
        self.Bind(wx.EVT_PAINT,self.OnPaint)
        self.lastRows=0
        self.translatedRows=[]
        self.magProfile=[]
        self.poolProfile=poolProfile
        self.poolProfileBack=poolProfileBack
        self.isBack=None
        self.map1.Bind(wx.EVT_MOTION,self.onMouseMotion)
        self.Bind(wx.EVT_ERASE_BACKGROUND,lambda evt:None)
        self.Bind(wx.EVT_KEY_DOWN, self.onKey)
        self.map1.Bind(wx.EVT_KEY_DOWN, self.onKey)
        self.bottomGraph.Bind(wx.EVT_KEY_DOWN, self.onKey)
        self.sideGraph.Bind(wx.EVT_KEY_DOWN, self.onKey)
        self.numGraphs=0
        self.stopped=False
        self.maxTime=0.0
        self.map1.SetToolTipString("           \n           \n           \n")
       
    def onKey(self,evt):
        if evt.GetKeyCode()==ord('Q'):
            self.Close()
        
    def onMouseMotion(self,evt):
        x,y=evt.GetPosition()
        self.sideGraph.setHighlightPoint(y)
        self.bottomGraph.setHighlightPoint(x)
        matrixW=len(self.translatedRows)
        if  matrixW==0:return
            
        matrixH=len(self.translatedRows[0])
        
        w,h=self.map1.GetClientSizeTuple()
        matrixX=(x*matrixW)/w
        matrixY=(y*matrixH)/h
        if matrixX<matrixW and matrixY<matrixH:
            value=self.translatedRows[matrixX][matrixY][3]
            if value!=None:
                if type(value)==type([]) or type(value)==type(()):
                    tipVal=""
                    for c in value:
                        tipVal+="%4.4f\n"%c
                    tipVal=tipVal[:-1]
                    self.map1.SetToolTipString(tipVal)
                else:
                    self.map1.SetToolTipString("%4.4f"%value)
            else:
                self.map1.SetToolTipString("")


        
    def UpdateMatrix(self,dtwMatrix,magneticValue,bestPos,goingBack,timeSinceStart):
        rows=len(dtwMatrix)
        if rows<=0 or self.stopped:
            return
                
        self.maxTime=max(self.maxTime,timeSinceStart)
        cols=len(dtwMatrix[0])
        if rows<self.lastRows:
            if self.maxTime<10.0:
                self.maxTime=timeSinceStart
                self.translatedRows=[]
                self.lastRows=0
            else:
                self.stopped=True
                return
        if goingBack!=self.isBack:
            print "going back?",goingBack
            self.isBack=goingBack
            if goingBack:
                self.sideGraph.setProfile(self.poolProfileBack)
            else:
                self.sideGraph.setProfile(self.poolProfile)
            
        for c in range(self.lastRows,rows):
            rowMin=None
            rowMax=0
            for val in dtwMatrix[c]:
                if val!=None:
                    if val[0]>rowMax:
                        rowMax=val[0]
                    if val[0]<rowMin or rowMin==None:
                        rowMin=val[0]                    
            if rowMax==0 or rowMin==None:
                rowMax=1
                rowMin=0
            if rowMin>0:
                rowMult=0.1/rowMin
            else:
                rowMult=1.0/rowMax
#            rowMax=math.sqrt(rowMax)
            self.translatedRows.append([])
            for val in dtwMatrix[c]:
                if val==None:
                    self.translatedRows[-1].append((0,0.3,0,None))
                else:
                    normal=val[0]*rowMult
                    normal=min(normal,1.0)
#                    normal=math.sqrt(val[0])/rowMax
                    self.translatedRows[-1].append((normal,normal,normal,val))
            if bestPos!=None:
                self.translatedRows[-1][bestPos]=(0,1.0,0,self.translatedRows[-1][bestPos][3])
        self.lastRows=rows
        self.map1.onMatrixData(rows,cols,lambda r,c:self.translatedRows[r][c][0:3])
        self.magProfile.append(magneticValue)
        self.bottomGraph.updateProfile(self.magProfile)
        wx.Yield()
        
    def OnPaint(self, evt):
        dc = wx.PaintDC(self)
        dc.Clear()
        
     
from array import array        

class SideGraph(wx.Window):
    def __init__(self, parent,poolProfile,**kwargs):
        kwargs['style'] = kwargs.setdefault('style', wx.NO_FULL_REPAINT_ON_RESIZE) | wx.NO_FULL_REPAINT_ON_RESIZE
        wx.Window.__init__(self, parent,**kwargs)
        self.poolProfile=poolProfile
        self.SetMinSize(wx.Size(50,250))
        self.bitmap=None
        self.image=None
        self.highlightPoint=None
        self.Bind(wx.EVT_PAINT,self.OnPaint)
        self.Bind(wx.EVT_SIZE, self.OnResize)        
        self.Bind(wx.EVT_ERASE_BACKGROUND,lambda evt:None)
        self.Show()
        
    def setProfile(self,profile):
        self.poolProfile=profile
        self.generateBitmap()
     
    def generateBitmap(self):
        w,h=self.GetClientSizeTuple()
        buffer=array('B',[0]*w*h*3)
        minVal=min(self.poolProfile)
        maxVal=max(self.poolProfile)
        scale=maxVal-minVal
        if scale==0:
            scale=1
        yPos=0
        profileLen=len(self.poolProfile)
        for y in range(0,h):
            profilePos=int((profileLen * float(y)) / h)
            value=self.poolProfile[profilePos]
            x=int((w-1)*(value - minVal) / (scale))
            x=(w-1)-x
            bufPos = 3*(y*w + x)
            buffer[bufPos]=255
            buffer[bufPos+1]=255
            buffer[bufPos+2]=255
        if self.highlightPoint!=None and self.highlightPoint<h:
            for x in range(0,w):
                buffer[3*(x+self.highlightPoint*w)]=255
        self.bitmap=wx.BitmapFromBuffer(w,h,buffer)
        self.Refresh()
        
    def setHighlightPoint(self,pt):
        self.highlightPoint=pt
        self.generateBitmap()
        
    def OnResize(self, evt):
        self.generateBitmap()

    def OnPaint(self, evt):
        dc = wx.PaintDC(self)
        if self.bitmap!=None:
            dc.DrawBitmap(self.bitmap, 0, 0)
        else:
            dc.SetBackground( wx.Brush("White") )
            dc.Clear() 

class BottomGraph(wx.Window):
    def __init__(self, parent,**kwargs):
        kwargs['style'] = kwargs.setdefault('style', wx.NO_FULL_REPAINT_ON_RESIZE) | wx.NO_FULL_REPAINT_ON_RESIZE
        wx.Window.__init__(self, parent,**kwargs)
        self.magProfile=[]
        self.SetMinSize(wx.Size(250,50))
        self.bitmap=None
        self.image=None
        self.highlightPoint=None
        self.Bind(wx.EVT_PAINT,self.OnPaint)
        self.Bind(wx.EVT_SIZE, self.OnResize)        
        self.Bind(wx.EVT_ERASE_BACKGROUND,lambda evt:None)
        self.Show()
        
    def updateProfile(self,profile):
        self.magProfile=profile
        self.generateBitmap()
        
    def generateBitmap(self):
        w,h=self.GetClientSizeTuple()
        if h!=0 and w!=0:
            buffer=array('B',[0]*w*h*3)
            profileLen=len(self.magProfile)
            if profileLen>0:
                minVal=min(self.magProfile)
                maxVal=max(self.magProfile)
                scale=maxVal-minVal
                if scale!=0:
                    for x in range(0,w):
                        profilePos=int((float(profileLen) * float(x)) / float(w))
                        value=self.magProfile[profilePos]
                        y=int((h-1)*(value - minVal) / (scale))
                        y=(h-1)-y
                        bufPos = 3*(y*w + x)
                        buffer[bufPos]=255
                        buffer[bufPos+1]=255
                        buffer[bufPos+2]=255
            if self.highlightPoint!=None:
                for y in range(0,h):
                    buffer[3*(self.highlightPoint+y*w)]=255
            self.bitmap=wx.BitmapFromBuffer(w,h,buffer)
            self.Refresh()
        
    def setHighlightPoint(self,pt):
        self.highlightPoint=pt
        self.generateBitmap()
        
    def OnResize(self, evt):
        self.generateBitmap()

    def OnPaint(self, evt):
        dc = wx.PaintDC(self)
        if self.bitmap!=None:
            dc.DrawBitmap(self.bitmap, 0, 0)
        else:
            dc.SetBackground( wx.Brush("White") )
            dc.Clear() 

        
class MatrixHeatMap(wx.Window):
    def __init__(self, parent,**kwargs):
        kwargs['style'] = kwargs.setdefault('style', wx.NO_FULL_REPAINT_ON_RESIZE) | wx.NO_FULL_REPAINT_ON_RESIZE
        wx.Window.__init__(self, parent,**kwargs)
        self.SetMinSize(wx.Size(250,250))
        self.bitmap=None
        self.image=None
        self.Bind(wx.EVT_PAINT,self.OnPaint)
        self.Bind(wx.EVT_SIZE, self.OnResize)
        self.markedPoint=None
        self.Bind(wx.EVT_LEFT_DOWN,self.onLeftClick)
        self.Bind(wx.EVT_ERASE_BACKGROUND,lambda evt:None)
        self.Show()
        
    def onMatrixData(self,rows,cols,matrixFn):
        buffer=array('B',[0]*rows*cols*3)
        pos=0
        for c in range(cols):
            for r in range(rows):
                (rv,gv,bv)=matrixFn(r,c)
                buffer[pos]=int(rv*255)
                buffer[pos+1]=int(gv*255)
                buffer[pos+2]=int(bv*255)
                pos+=3
        self.image=wx.ImageFromBuffer(rows,cols,buffer)
        self.generateBitmap()
        
    def generateBitmap(self):
        if self.image!=None:
            w,h=self.GetClientSizeTuple()
            scaledImage=self.image.Scale(w,h)
            self.bitmap=wx.BitmapFromImage(scaledImage)
            dc = wx.MemoryDC()
            dc.SelectObject(self.bitmap)
            dc.SetPen(wx.Pen((0,255,255)))
            dc.DrawLine(0,0,w,h)

            if self.markedPoint!=None:
                x,y=self.markedPoint
                dc.SetPen(wx.Pen((255,0,0)))
                dc.DrawLine(x,0,x,h)
                dc.DrawLine(0,y,w,y)

            dc.SelectObject(wx.NullBitmap)            
            
            self.Refresh()
        
    def onLeftClick(self,evt):
        x,y=evt.GetPosition()
        self.markedPoint=(x,y)
        self.generateBitmap()                
        
        
    def OnResize(self, evt):
        self.generateBitmap()

    def OnPaint(self, evt):
        dc = wx.PaintDC(self)
        if self.bitmap!=None:
            dc.DrawBitmap(self.bitmap, 0, 0)
        else:
            dc.SetBackground( wx.Brush("White") )
            dc.Clear() 

            
if __name__=="__main__":
    app = wx.App(False)    
    frame =      DTWDebugWindow()
    frame.UpdateMatrix([[(0,0),(1,0),(2,0),(3,0),(4,0)],[(4,0),(3,0),(2,0),(1,0),(0,0)]])
    frame.Show()
    app.MainLoop()

