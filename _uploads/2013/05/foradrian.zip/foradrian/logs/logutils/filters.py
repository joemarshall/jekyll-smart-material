
#
#
# dynamic time warping - 
#
# downsample the pool profile to 250 samples ie. 10ths of a metre
#
#
# each time we get a new flat point (at .2th of a second max), then
# we need to score all the possible points on the pool profile against the new point
# to create a new column in our DTW matrix
# 
# we can assume: 1)it can only move a certain distance between points (based on speed, ?and average speed variation?)
#                2)the absolute position can only be within a certain range (based on overall speed)
#                3)we only go forwards
#                this rules out a bunch of points
#
# so need to calculate <250 scores for each new sample (based on min/max possible positions)
# - scores based on the difference between flat points and the difference in the profile?
#   or something cunninger?
#
# to score each point on the column, S(flatPt,poolPos) = min for all X[(S(flatPt-1,x) + distFn(x,dt,deltaFlatPts,poolPos))]
# nb. this is potentially o(n^2) in pool profile samples (ie. 
# each time step which is a pain, but locality constraints above should hopefully make it practical
#                
# at each point, the estimated position is the minimum of the matrix last column
#
# nb. do we want to score for some kind of flatness / mean angle and store that in each position too, used for the scoring?

# use only flat values
# so only track each time we are flat, anything more is overkill as
# we have no extra information
#

#
#
# already have an estimated posn and velocity from the acceleration filter
#
# each time we hit a good (flat) signal on the magnetic sensor:
# 1)exhaustive search for est. posn +- 1 metre
# 2)update pos and velocity estimate based on best score from this

#
# with the particle filter thing - it was okay, but overestimated speed due to missing out early details, where
# a later bit looked the same as an earlier bit
#
# can we make it betterer by: 
# 1)feature list - something like the segment algorithm - check which features are prior to the 
#   search buffer, and check for successive maxima and minima (or even flat points) that match each one
#   - this should be done some way that allows for them to change speed (as speed over the length may change)
#
# 2)smoothing somehow - can we smooth in a way that doesn't lose time coherence for things very close to current time
#   eg. if we run a reverse smoothing from the current point, the current point has no delay, and delay increases by
#   1 point per point up to the buffer full moment
#   or even just smooth, then take 1/2 buffer of unsmoothed afterwards
#   (could also smooth and match, which might give us a good guess at where
#   we were 2 seconds ago or whatever, and then use a secondary algorithm to
#   get the rest
#   or even:
#     smooth + match, estimate constant speed since 2 seconds ago, then use accelerometer with a
#                     complementary filter? Maybe that would do the job
#
##
#    check with smoothing if we can make an fir or iir low pass filter with much faster response
#    as that could get rid of smoothing delays
#
#
#    stupid idea - can we smooth with a quadratic regression or similar
#                  and then extrapolate to current time in the smoother?
#                - this is LOESS estimation: 
#                - use numpy.polyfit to try it - weights for most recent position higher, going down to 0 for start of history array?
#                - store times as x values
#                  and data as y values
#                  and use numpy.roll to add new values (so it is deque-like)
#                - weights can be a constant array
#


# using the profile of the pool, can we:
#
# 
# take the whole length so far's history (smoothed?) and match that with the segmented profile,
# see which one fits best (assuming max segment number = .3 of a second per segment)
# either of all segment sets, or of two candidates (current and next)
#
# (maybe use a spaced out or monte-carlo sampling to do this difference quickly rather than comparing all points)
#
# we know the start point, and we know the now point, so this is just a pretty basic stretching
# out of the history buffer to fit the segment buffer
#
# in fact, if we do this, do we even need the segmenting at all?
#
# do we need to smooth the input? probably, and assume a delay / hence a constant distance forward
#
# if we have already got good fit results previously, can we use these for further estimates
# and only match the rear-end to give speed change allowance
# eg. if we match half the pool, then only match from half way
# or even only match for maybe 1/2 pool or something
#
# how about:
#
# track start of length as we have already
#
# particle filter, updated (say) 5 times a second
# particle values are a single value of metres/second for the length
# particle update = weighted sample, then change speed slightly, nothing else
# particle scoring = we know where in the pool we should be, and how stretched out the pool profile should be, so we can line up the two
# and do some kind of scoring of the last 1/4 pool or so
#
# assume magnitude of changes is roughly the same, but offset may not be
#
# score by: take N points, then 
# take mean of data points and profile points
# score = sum over T[ ((D(t)-mean)-(P(t)-mean))^2 ]
#
# before the first 1/4 pool is reached, we will have uncertain results - need to make sure a range of possibilities stay around until then maybe?
#
# take history buffer for last 
#
# smoothing (250 samples / giving 125 sample/250ms delay)
# history buffer
#
#







#Particle filtering to get absolute position and short term velocity along pool.

#input values are:
#1)magnetic sensor magnitude
#2)acceleration
#3)body angle

#Each particle contains:
#1)assumed position in the pool
#2)assumed velocity (diff from last particle)
#3)acceleration (difference in velocity since previous particle)

#we know: magnetic shape of pool

#at each step, score particles based on:
#1)position difference based on difference of assumed position magnitude and observed magnitude (squared difference?)
#plus? or (1+x)*(1+x)
#2)velocity based on previous velocity + acceleration value (squared difference?)

#weighted generation of new particles by:
#1)new pos = pos + random value
#2)new velocity = difference in position

#generation of displayed output position by clustering and taking best scoring cluster?

#random seeding of new particles:
#either when no good results are showing or just all the time
#seed them as random positions, zero velocity? or as starting at the wall, zero velocity?


#How to do this in python code:
#1)in and out selection, set to a single length
#2)'run processor on selection', list of processors
#3)generate magnetic shape graph from selection
#3)ParticleFilterProcessor - takes magnetic shape graph, then runs as a standard
#  processor to generate a new column of values


from collections import deque
import random
import bisect
import time
import math
from processors import averageBuffer,slopeBuffer

class accelAndMagneticTracker:
    def __init__(self,holder,selectionIn,selectionOut):
        self.holder=holder
        if selectionIn==None or selectionOut==None:
            return
        self.selectionIn=selectionIn
        self.selectionOut=selectionOut
        self.magneticDensityShape=[]
        self.magneticDensityColumn=holder.getColumnFromName("sqrt(mag_x^2+mag_y^2+mag_z^2)")
        values,minTime,maxTime=holder.getRange((selectionIn,selectionOut),self.magneticDensityColumn)
        for c in values:
            self.magneticDensityShape.append(c)
        dirValues,minTime,maxTime=holder.getRange((selectionIn,selectionOut),holder.getColumnFromName("ori_x"))
        self.poolDirection=dirValues[int(len(values)/2)]    
    
        self.magneticDensityLengthMultiplier=1.0 / len(self.magneticDensityShape)
        
        # smoothing (non-biased so we don't have a shift)
        smoothingLen=500
        smoother=deque(maxlen=smoothingLen)
                
        self.smoothedMagneticDensity=[]
        # first, add half as many values to the buffer
        # then for each sample we take mean of the buffer
        # and add another sample
        for c in self.magneticDensityShape[0:smoothingLen/2]:
            smoother.append(c)
        for c in self.magneticDensityShape[smoothingLen/2:]:
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.append(c)
        for c in range(0,smoothingLen/2):
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.popleft()

        magProcess=self.accelAndMagneticProcessor(self.smoothedMagneticDensity,self.poolDirection,self.magneticDensityColumn,holder.getColumnFromName("forwards_mpsps"),holder.getColumnFromName("legangle_degrees"),holder.getColumnFromName("ori_x"),holder.getColumnFromName("roll_degrees"),selectionIn-5.0,selectionOut+5.0)
        self.holder.runProcess(magProcess)

    def mean(self,buf):
        sum=0.0
        count=0.0
        for c in buf:
            sum+=c
            count+=1.0
        if count==0.0:
            return 0.0
        else:
            return sum/count
        
        
    class accelAndMagneticProcessor:
        def __init__(self,poolProfile,poolDirection,magneticCol,accelCol,legAngleCol,directionCol,rollCol,startEverything,stopEverything):
            self.poolProfile,self.poolDirection,self.magneticCol,self.accelCol,self.legAngleCol,self.directionCol,self.rollCol=(poolProfile,poolDirection,magneticCol,accelCol,legAngleCol,directionCol,rollCol)            
            self.startEverything=startEverything
            self.stopEverything=stopEverything

            self.lastVelocity=0       
            self.lastTime=None
            self.timeColumn=0
            self.timeMultiplier=1
            self.accelHistory=deque(maxlen=1000)
            self.directionHistory=deque(maxlen=1000)
            self.legAngleHistory=deque(maxlen=1000)
            self.dtHistory=deque(maxlen=1000)
            self.stopped=True
            self.poolPos=0.0
            
            self.poolProfileMinimums=[]
            self.poolProfileMaximums=[]
            maxVal=self.poolProfile[0]
            minVal=self.poolProfile[0]
            for c in self.poolProfile:
                if c<minVal: minVal=c
                if c>maxVal: maxVal=c
#                print c,minVal,maxVal
                self.poolProfileMinimums.append(minVal)
                self.poolProfileMaximums.append(maxVal)                
            
            self.curLengthStart=0.0

            # sparsely sampled history points for this length
            self.curLengthMagHistory=deque()
            self.curLengthMagMin=None
            self.curLengthMagMax=None
            
            self.lastUpdateTime=0.0
            self.dbgValue=0.0
            self.dbgValue2=45.0
            
            
        def initHolder(self,holder):
            nanoCol=holder.getColumnFromName("nanotime")
            if nanoCol!=-1:
                self.timeColumn=nanoCol
                self.timeMultiplier=1.0/1000000000.0
            
        def processValues(self,values):                
            thisTime=float(values[self.timeColumn])*self.timeMultiplier
            if values[0]<self.startEverything or values[0]>self.stopEverything:
                values.append(0.0)
                values.append(0.0)
                values.append(0.0)
                values.append(45.0)
                return values

            curAccel=values[self.accelCol]
            curDirection=values[self.directionCol]
            curLegAngle=values[self.legAngleCol]
            curMagnetic=values[self.magneticCol]
            curRoll=values[self.rollCol]
            if self.lastTime==None:
                self.lastVelocity=0
            else:
                diffTime=thisTime-self.lastTime
                if curLegAngle>40:  
                    # stopped - assume zero speed
                    self.lastVelocity=0
                    self.poolPos=0
                    if not self.stopped:
                        self.legAngleHistory.clear()
                        self.directionHistory.clear()
                        self.accelHistory.clear()
                        self.dtHistory.clear()
                    self.stopped=True
                    self.legAngleHistory.append(curLegAngle)
                    self.directionHistory.append(curDirection)
                    self.accelHistory.append(curAccel)
                    self.dtHistory.append(diffTime)
                else:
                    # swimming - integrate speed
                    if self.stopped:
                        # just started a length - check if there is any previous
                        # acceleration which we need to take account of
                        # since either: moment of turn (if we were swimming < 1000 data points ago)
                        #            or first point of verticality where we were
                        #            roughly pointing poolwards (if we started from the wall)
                        # start of a length:
                        self.curLengthMagHistory.clear()
                        self.curLengthStart=thisTime
                        self.curLengthMagHistory.append((0.0,curMagnetic))
                        self.curLengthMagMax=curMagnetic
                        self.curLengthMagMin=curMagnetic
                        startedPos=len(self.legAngleHistory)
                        if len(self.legAngleHistory)<1000:
                            # after a turn
                            # look for a turn - where pool direction sharply changes                        
                            # and also go back until leg angle stops rising
                            lastLegAngle=curLegAngle
                            foundStart=False
                            curPos=len(self.legAngleHistory)-1
                            while (not foundStart) and curPos>0:
                                curPos-=1
                                thisAngle=self.legAngleHistory[curPos]
                                thisDirection=self.directionHistory[curPos]
                                if abs(thisAngle)<abs(lastLegAngle):
                                    foundStart=True
                                directionDiff=abs(thisDirection-curDirection)
                                if directionDiff>math.pi:
                                    directionDiff=2.0*math.pi - directionDiff
                                if abs(thisDirection - curDirection)>math.pi*0.25:
                                    foundStart=True
                            if curPos>0:
                                startedPos=curPos
                        else:
                            # go back until leg angle stops rising, or direction goes off centre
                            lastLegAngle=curLegAngle
                            foundStart=False
                            curPos=len(self.legAngleHistory)-1
                            while (not foundStart) and curPos>0:
                                curPos-=1
                                thisAngle=self.legAngleHistory[curPos]
                                thisDirection=self.directionHistory[curPos]
                                if abs(thisAngle)<abs(lastLegAngle):
                                    foundStart=True
                                directionDiff=abs(thisDirection-curDirection)
                                if directionDiff>math.pi:
                                    directionDiff=2.0*math.pi - directionDiff
                                if abs(thisDirection - curDirection)>math.pi*0.25:
                                    foundStart=True
                            if curPos>0:
                                startedPos=curPos
                        self.lastVelocity=0
                        # this code makes the assumption that we never go backwards during a start!
                        for c in range(startedPos,len(self.legAngleHistory)):
                            self.lastVelocity=self.lastVelocity+ (self.accelHistory[c]*self.dtHistory[c])
#                            self.poolPos+=self.lastVelocity*self.dtHistory[c]
                            self.poolPos=max(self.lastVelocity*self.dtHistory[c]+self.poolPos,0)
                        self.lastVelocity=max(self.lastVelocity,0)
                        #print len(self.legAngleHistory)-startedPos
                        self.stopped=False

                    # normal pool update - never go backwards
                    self.lastVelocity= max(self.lastVelocity+ (curAccel*(diffTime)),0)
                    self.poolPos+=self.lastVelocity*diffTime
                    
                    if abs(curRoll)<10.0:
                        # we are flat - magnetic history will be low noise, so add this point to the reference set
                        # keep this reference set sparse[ish] so that when we stretch it to match, it is
                        # somewhat quicker
                        if thisTime-self.lastUpdateTime>0.2:
                            self.lastUpdateTime=thisTime
                            self.curLengthMagHistory.append((thisTime-self.curLengthStart,curMagnetic))
                            self.curLengthMagMax=max(curMagnetic,self.curLengthMagMax)
                            self.curLengthMagMin=min(curMagnetic,self.curLengthMagMin)
                            self.estimateMagneticPosition(thisTime-self.curLengthStart,self.poolPos)
                    
            values.append(self.lastVelocity)
            values.append(self.poolPos)

            values.append(self.dbgValue)
            values.append(self.dbgValue2)
            self.lastTime=thisTime
            return values
            
        def estimateMagneticPosition(self,timeInLength,positionEstimate):
            if timeInLength>0.0 and len(self.curLengthMagHistory)>=4:
                guessedPosition=positionEstimate/25.0
                
                # we have a position estimate
                # try positions around this
                # 
                
                guessedMagnetic=self.curLengthMagHistory[-1][1]
                
                numProfilePoints=len(self.poolProfile)
                posInProfile=float(numProfilePoints)*guessedPosition
                if int(posInProfile)>=numProfilePoints:
                    posInProfile=numProfilePoints-1
                    
                maxBeforeThis=self.poolProfileMaximums[int(posInProfile)]
                minBeforeThis=self.poolProfileMinimums[int(posInProfile)]
                
                goingUp=(self.poolProfile[int(posInProfile)]-self.poolProfile[int(posInProfile)-1])>0
                if goingUp:
                    # going up, use minimum to calibrate against
                    offset=self.curLengthMagMin - minBeforeThis
                else:
                    # going down, use maximum to calibrate against
                    offset=self.curLengthMagMax-maxBeforeThis
                self.dbgValue2=self.poolProfile[int(posInProfile)]
                curDiff= guessedMagnetic - self.poolProfile[int(posInProfile)]-offset
                self.dbgValue=curDiff
#                print curDiff
                if curDiff>0.2:
                    if goingUp:
                        self.poolPos=self.poolPos+0.01
                    else:
                        self.poolPos=self.poolPos-0.01
                elif curDiff<-0.2:
                    if goingUp:
                        self.poolPos=self.poolPos-0.01
                    else:
                        self.poolPos=self.poolPos+0.01
                
#                curDiff*=curDiff
#                doneMove=True
#                while doneMove:
##                    print curDiff,
#                    # try moving right
                    # tryPoint1=posInProfile+1
                    # tryDiff1=None
                    # if tryPoint1<numProfilePoints:
                        # tryDiff1= guessedMagnetic - self.poolProfile[int(tryPoint1)]-offset
                        # tryDiff1*=tryDiff1
                    # else:
                        # doneMove=True
                    # # try moving left
                    # tryPoint2=posInProfile-1
                    # tryDiff2=None
                    # if tryPoint2>=0:
                        # tryDiff2= guessedMagnetic - self.poolProfile[int(tryPoint2)]-offset
                        # tryDiff2*=tryDiff2
                    # else:
                        # doneMove=True
                    # if tryDiff1!=None and tryDiff1<curDiff and tryDiff1<tryDiff2:
                        # posInProfile=tryPoint1
                        # curDiff=tryDiff1
 # #                       print "+",
                    # elif tryDiff2!=None and tryDiff2<curDiff and tryDiff2<tryDiff1:
                        # posInProfile=tryPoint2
                        # curDiff=tryDiff2
 # #                       print "-",
                    # else:
                        # doneMove=False
# #                    print "!",posInProfile,tryDiff1,tryDiff2
                # bestPos=float(posInProfile)/numProfilePoints                
                # bestPos*=25.0
# #                print bestPos,self.poolPos
                # poolError=bestPos-self.poolPos
                # self.poolPos=bestPos
                # velocityError=poolError / timeInLength
                # self.lastVelocity=self.lastVelocity+velocityError

        
        # history buffer is a set of tuples - (timeInLength,magneticIntensity)
        # pos is fraction of length completed
        def scoreHistoryPosition(self,pos,timeInLength):        
            numProfilePoints=len(self.poolProfile)
            posInProfile=float(numProfilePoints)*pos
            historyToProfileMult=pos/timeInLength
            
            # find some min / max metrics of the profile and our history - assuming we have a good guess
            # these should be roughly similar
            # nb: should keep track of these as we go along
            # nb2: should this be mean? should we scale vertically or just shift?
            maxHistory=max(zip(self.curLengthMagHistory)[1])
            minHistory=min(zip(self.curLengthMagHistory)[1])
            minProfile = min(self.poolProfile[0:int(posInProfile)])
            maxProfile = max(self.poolProfile[0:int(posInProfile)])
                        
            score=0            
                        
            pt=self.curLengthMagHistory[-1]
            histTime,histMag = pt
            histPos = histTime*historyToProfileMult
            profileMag= self.poolProfile[int(histPos)]
            diff=profileMag-histMag
            score+=diff*diff
#            histNormalised = (histMag -minHistory)/(maxHistory-minHistory)
            return score
            
            
        def newColumnNames(self,names):
            names.append("magSpeed")
            names.append("magPos")
            names.append("dbg1")
            names.append("dbg2")
            return names
            

class simpleParticleTracker:
    def __init__(self,holder,selectionIn,selectionOut):
        self.holder=holder
        if selectionIn==None or selectionOut==None:
            return
            
        self.selectionIn=selectionIn
        self.selectionOut=selectionOut
        self.magneticDensityShape=[]
        self.magneticDensityColumn=holder.getColumnFromName("sqrt(mag_x^2+mag_y^2+mag_z^2)")
        values,minTime,maxTime=holder.getRange((selectionIn,selectionOut),self.magneticDensityColumn)
        for c in values:
            self.magneticDensityShape.append(c)
        dirValues,minTime,maxTime=holder.getRange((selectionIn,selectionOut),holder.getColumnFromName("ori_x"))
        self.poolDirection=dirValues[int(len(values)/2)]    
    
        self.magneticDensityLengthMultiplier=1.0 / len(self.magneticDensityShape)
        
        # smoothing (non-biased so we don't have a shift)
        smoothingLen=500
        smoother=deque(maxlen=smoothingLen)
                
        self.smoothedMagneticDensity=[]
        # first, add half as many values to the buffer
        # then for each sample we take mean of the buffer
        # and add another sample
        for c in self.magneticDensityShape[0:smoothingLen/2]:
            smoother.append(c)
        for c in self.magneticDensityShape[smoothingLen/2:]:
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.append(c)
        for c in range(0,smoothingLen/2):
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.popleft()
            
            
            
            
        magProcess=self.magneticParticleProcessor(self.smoothedMagneticDensity,self.poolDirection,self.magneticDensityColumn,holder.getColumnFromName("forwards_mpsps"),holder.getColumnFromName("legangle_degrees"),holder.getColumnFromName("ori_x"),selectionIn)
        self.holder.runProcess(magProcess)
        
        startPos=0
        self.segments=[]
        for c in range(0,100):
            centrePos=int(((c+0.5)*len(self.smoothedMagneticDensity))/100.0)
            stopped=False
            while not stopped:
                curVal=self.smoothedMagneticDensity[centrePos]
                if centrePos>0:
                    leftVal=self.smoothedMagneticDensity[centrePos-1]
                else:
                    leftVal=None
                if centrePos<len(self.smoothedMagneticDensity)-1:
                    rightVal=self.smoothedMagneticDensity[centrePos+1]
                    if leftVal !=None and rightVal!=None:
                        if rightVal<curVal and leftVal<curVal:
                            stopped=True
                        elif rightVal>curVal and leftVal>curVal:
                            stopped=True
                        else:
                            centrePos+=1
                    else:
                        centrePos+=1                    
                else:
                    rightVal=None
                    stopped=True
                
            if len(self.segments)==0 or self.segments[-1][0]!=centrePos:
                self.segments.append((centrePos,self.smoothedMagneticDensity[centrePos]))
            
        self.segmentDensity=[]
        pos=0
        curSegment=0
        curVal=self.segments[0][1]
        multiplier=25.0/len(self.smoothedMagneticDensity)
        for c in self.smoothedMagneticDensity:
            if curSegment<len(self.segments)-1 and pos>=self.segments[curSegment+1][0]:
                curSegment+=1
                curVal=self.segments[curSegment][1]
            self.segmentDensity.append(curVal)
            pos+=1
        self.holder.runProcess(self.debugProcessor1(self.selectionIn,self.segmentDensity))
#        self.holder.runProcess(self.debugProcessor1(self.selectionIn,self.smoothedMagneticDensity))
        

    class magneticParticleProcessor:
        def __init__(self,poolProfile,poolDirection,magneticCol,accelCol,bodyAngleCol,directionColumn,startEverything):
            self.poolProfile,self.poolDirection,self.magneticCol,self.accelCol,self.bodyAngleCol,self.directionColumn=(poolProfile,poolDirection,magneticCol,accelCol,bodyAngleCol,directionColumn)            
            self.startEverything=startEverything

            # initially we have 38 evenly spaced particles between .2 and 4 metres / second
            # note, this assumes 25 metre pool here
            self.initialSpeedGuesses=[(x/(10.0*25.0),1) for x in range(2,40)]
            self.particles=[x for x in self.initialSpeedGuesses]
            totalParticles=0
            self.newParticleSources=[]
            counter=len(self.particles)/3
            while totalParticles<len(self.particles):                
                if counter+totalParticles>len(self.particles):
                    counter=len(self.particles)-counter
                totalParticles+=counter
                self.newParticleSources.append(counter)
                counter/=2
                if counter<1:
                    counter=1
            self.lengthStartTime=None
            
            self.timeColumn=0
            self.curValue=0.0
            self.curDirection=0
            self.lastTime=None
            self.history=deque()
            self.smoother=averageBuffer(250)
            self.timeToParticleUpdate=0
            
        def initHolder(self,holder):
            nanoCol=holder.getColumnFromName("nanotime")
            if nanoCol!=-1:
                # use more accurate nanosecond timing
                self.timeColumn=nanoCol
                self.timeMultiplier=1.0/1000000000.0            
            
            
        def processValues(self,values):
            if values[0]<self.startEverything:
                values.append(0)
                return values
            curTime=values[self.timeColumn]*self.timeMultiplier
            direction=values[self.directionColumn]
            bodyAngle=values[self.bodyAngleCol]
            magAmplitude=values[self.magneticCol]
            
            if self.lastTime!=None:
                dt=curTime-self.lastTime
                directionDiff=abs(self.poolDirection-direction)
                if directionDiff>math.pi:
                    directionDiff=2*math.pi-directionDiff
                if directionDiff<math.pi/2:
                    # going in pool direction
                    withPool=True
                else:
                    # going back
                    withPool=False                
                if abs(bodyAngle)>40:
                    # high body angle = not swimming
                    self.curDirection=0
                elif self.curDirection==0:
                    # initialise for starting to swim (assume that we are at one end of the pool)
                    self.lengthStartTime=curTime                    
                    # reset particles to cover full range
                    self.particles=[x for x in self.initialSpeedGuesses]
                    if withPool:
                        self.curDirection=1
                        self.curValue=0.0
                    else:
                        self.curDirection=-1
                        self.curValue=1.0
                    # update particles in .2 seconds - we only do a certain amount of
                    # particle updates because it is slow, and also we need some history
                    # before it will work even vaguely well
                    self.timeToParticleUpdate=0.2
                    self.history.clear()
                    self.smoother.clear()
                else:                    
                    self.history.append(magAmplitude)
#                    self.history.append(self.smoother.addValue(magAmplitude))
                    self.timeToParticleUpdate-=dt
                    if self.timeToParticleUpdate<0:
                        self.timeToParticleUpdate=0.2
                        self.curValue=self.doParticleScoring(curTime)
            values.append(self.curValue)
            self.lastTime=curTime
            return values
            
        def doParticleScoring(self,curTime):
            timeInLength=curTime - self.lengthStartTime
            profileLength=len(self.poolProfile)
            historyLen=len(self.history)
            direction=self.curDirection
            for c in range(0,len(self.particles)):
                avgVelocity=self.particles[c][0]
                currentPos = avgVelocity * timeInLength * profileLength
                if currentPos>len(self.poolProfile):
                    # if they were going this fast, they'd have gone past the end of the pool by now
                    self.particles[c]=(avgVelocity,0)
                else:
                    numPoints=100.0
                    # plausibly hits a location in the pool, so compare history against pool profile
                    # for at most 1/4 of the pool
                    poolProfileLengthToScan = min(profileLength/4,currentPos)
                    poolProfileStep=(-poolProfileLengthToScan) / numPoints
                    profileStartPos=float(currentPos)
                    
                    historyLengthToScan=(poolProfileLengthToScan / currentPos)*historyLen
                    historyStep=(-historyLengthToScan) / numPoints
                    historyStartPos=float(historyLen-1)
                    
                    if direction==-1:
                        profileStartPos=float(profileLength-1-currentPos)
                        poolProfileStep=-poolProfileStep
                    
                    score=0
                    historyPos=historyStartPos
                    profilePos=profileStartPos
                    historyOffset=0
                    profileOffset=0
#                    historySum=self.history[int(historyPos)]
#                    profileSum=self.poolProfile[int(profilePos)]
                    for d in range(0,int(numPoints)):
                        historyVal=self.history[int(historyPos)]
                        profileVal=self.poolProfile[int(profilePos)]
#                        if historyVal<historySum:historySum=historyVal
#                        if profileVal<profileSum:profileSum=profileVal
                        historyOffset+=historyVal
                        profileOffset+=profileVal
                        profilePos+=poolProfileStep
                        historyPos+=historyStep
                    profileOffset*=(1.0/numPoints)
                    historyOffset*=(1.0/numPoints)
                    historyPos=historyStartPos
                    profilePos=profileStartPos
#                    if c==0:
#                        print profileSum,historySum
                    for d in range(int(numPoints/10)):
                        histAvg=0
                        profileAvg=0
                        
                        for e in range(0,10):
                            historyVal=self.history[int(historyPos)]
                            profileVal=self.poolProfile[int(profilePos)]
                            histAvg+=historyVal-historyOffset
                            profileAvg+=profileVal-profileOffset
                            profilePos+=poolProfileStep
                            historyPos+=historyStep
                        diff= (profileAvg-histAvg)*(profileAvg-histAvg)
                        score+=diff
                    score=1.0/(score+0.0001)
                    score=0.99*self.particles[c][1] + 0.01*score
                    self.particles[c]=(avgVelocity,score)
            self.particles.sort(key=lambda (velocity,score):-score)
            
            bestSpeed=self.particles[0][0]
#            newParticles=[]
#            pos=0
#            for source,count in enumerate(self.newParticleSources):
#                for c in range(0,count):
#                    (avg,score)=self.particles[source]
#                    avg=random.gauss(avg,avg*0.01)
#                    if avg<1/(10.0*25.0): avg=1/(10.0*25.0)
#                    newParticles.append((avg,score))
#                    pos+=1
#            self.particles=newParticles                
#            print self.particles[0][0] * timeInLength,self.particles[:2],"\n"
            if direction==-1:
                return 1.0-bestSpeed * timeInLength
            else:
                return bestSpeed * timeInLength
            
        def newColumnNames(self,names):
            names.append("magPos")
            return names
            
    def mean(self,buf):
        sum=0.0
        count=0.0
        for c in buf:
            sum+=c
            count+=1.0
        if count==0.0:
            return 0.0
        else:
            return sum/count

    class debugProcessor1:
        def __init__(self,startTime,buf1,colName="dbg1"):
            self.colName=colName
            self.startTime=startTime
            self.pos=0
            self.buf1=buf1
            self.dir=1
        
        def processValues(self,values):
            curTime=values[0]
            val1=self.buf1[0]
            if curTime>self.startTime:
                if self.pos<len(self.buf1):
                    val1=self.buf1[self.pos]
                self.pos+=self.dir
                if self.pos>=len(self.buf1):
                    self.dir=-1
                    self.pos=len(self.buf1)-1
                    val1=0
                    self.startTime=curTime+5
                if self.pos<0:
                    self.dir=1
                    self.pos=0
                    val1=0
                    self.startTime=curTime+5
            values.append(val1)
            return values

        def newColumnNames(self,names):
            names.extend([self.colName])
            return names


class simpleMagneticTracker:
    def __init__(self,holder,selectionIn,selectionOut):
        self.holder=holder
        if selectionIn==None or selectionOut==None:
            return
            
        self.selectionIn=selectionIn
        self.selectionOut=selectionOut
        self.magneticDensityShape=[]
        self.magneticDensityColumn=holder.getColumnFromName("sqrt(mag_x^2+mag_y^2+mag_z^2)")
        values,minTime,maxTime=holder.getRange((selectionIn,selectionOut),self.magneticDensityColumn)
        for c in values:
            self.magneticDensityShape.append(c)
        dirValues,minTime,maxTime=holder.getRange((selectionIn,selectionOut),holder.getColumnFromName("ori_x"))
        self.poolDirection=dirValues[int(len(values)/2)]    
    
        self.magneticDensityLengthMultiplier=1.0 / len(self.magneticDensityShape)
        
        # smoothing (non-biased so we don't have a shift)
        smoothingLen=500
        smoother=deque(maxlen=smoothingLen)
        
        self.smoothedMagneticDensity=[]
        # first, add half as many values to the buffer
        # then for each sample we take mean of the buffer
        # and add another sample
        for c in self.magneticDensityShape[0:smoothingLen/2]:
            smoother.append(c)
        for c in self.magneticDensityShape[smoothingLen/2:]:
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.append(c)
        for c in range(0,smoothingLen/2):
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.popleft()
            

        # split the pool up into segments, defined by 
        # maxima and minima of the smoothed magnetic density
        # map
        
        self.segments=[]
        lastPos=0
        for c in range(0,100):
            centrePos=int(((c+0.5)*len(self.smoothedMagneticDensity))/100.0)
            stopped=False
            while not stopped:
                curVal=self.smoothedMagneticDensity[centrePos]
                if centrePos>0:
                    leftVal=self.smoothedMagneticDensity[centrePos-1]
                else:
                    leftVal=None
                if centrePos<len(self.smoothedMagneticDensity)-1:
                    rightVal=self.smoothedMagneticDensity[centrePos+1]
                    if leftVal !=None and rightVal!=None:
                        if rightVal<curVal and leftVal<curVal:
                            stopped=True
                        elif rightVal>curVal and leftVal>curVal:
                            stopped=True
                        else:
                            centrePos+=1
                    else:
                        centrePos+=1                    
                else:
                    rightVal=None
                    stopped=True
                
            if lastPos!=centrePos:
                self.segments.append((lastPos,centrePos))
                lastPos=centrePos
        if lastPos!=len(self.smoothedMagneticDensity):
                self.segments.append((lastPos,len(self.smoothedMagneticDensity)))        
            
        self.segmentDensity=[]
        pos=0
        curSegment=0
        curVal=self.segments[0][1]
        multiplier=25.0/len(self.smoothedMagneticDensity)
        for c in self.smoothedMagneticDensity:
            if curSegment<len(self.segments)-1 and pos>=self.segments[curSegment+1][0]:
                curSegment+=1
                curVal=self.segments[curSegment][1]
            self.segmentDensity.append(curVal)
            pos+=1
        self.holder.runProcess(self.debugProcessor1(self.selectionIn,self.segmentDensity))
            
            
            
            
            
        #magProcess=self.magneticPosProcessor(self.smoothedMagneticDensity,self.segments,self.poolDirection,self.magneticDensityColumn,holder.getColumnFromName("forwards_mpsps"),holder.getColumnFromName("legangle_degrees"),holder.getColumnFromName("ori_x"),selectionIn)
        #self.holder.runProcess(magProcess)

    class magneticPosProcessor:
        def __init__(self,poolProfile,poolSegments,poolDirection,magneticCol,accelCol,bodyAngleCol,directionColumn,startEverything):
            self.poolProfile,self.poolSegments,self.poolDirection,self.magneticCol,self.accelCol,self.bodyAngleCol,self.directionColumn=(poolProfile,poolSegments,poolDirection,magneticCol,accelCol,bodyAngleCol,directionColumn)            
            self.startEverything=startEverything
            self.timeColumn=0
            self.curValue=0
            self.curDirection=0
            self.lastTime=None
            self.history=deque()
            self.curSegment=0
            self.historyStart=0
            self.historyEnd=0
            self.searchTime=0
            
        def initHolder(self,holder):
            nanoCol=holder.getColumnFromName("nanotime")
            if nanoCol!=-1:
                # use more accurate nanosecond timing
                self.timeColumn=nanoCol
                self.timeMultiplier=1.0/1000000000.0            
            
            
        def processValues(self,values):
            if values[0]<self.startEverything:
                values.append(0)
                return values
            curTime=values[self.timeColumn]*self.timeMultiplier
            direction=values[self.directionColumn]
            bodyAngle=values[self.bodyAngleCol]
            magAmplitude=values[self.magneticCol]
            
            if self.lastTime==None:
                self.curValue=0.0
            else:                        
                dt=curTime-self.lastTime
                directionDiff=abs(self.poolDirection-direction)
                if directionDiff>math.pi:
                    directionDiff=2*math.pi-directionDiff
                if directionDiff<math.pi/2:
                    # going in pool direction
                    withPool=True
                else:
                    # going back
                    withPool=False
                
                if abs(bodyAngle)>40:
                    # high body angle = not swimming
                    self.curDirection=0
                    self.curValue=0
                    self.history.clear()
                    self.searchTime=0.0
                elif self.curDirection==0:
                    self.history.clear()
                    self.historyStart=curTime
                    if withPool:
                        self.curDirection=1
                        self.curValue=0.0
                        self.curSegment=0
                    else:
                        self.curDirection=-1
                        self.curValue=1.0
                        self.curSegment=len(self.segments)-1
                else:
                    self.history.append(magAmplitude)
                    self.searchTime-=dt
                    if self.searchTime<0:
                        self.searchTime=0.2
                    self.curValue=self.tryFindSegment()
            values.append(float(self.curValue))
            self.lastTime=curTime
            return values
            
        def tryFindSegment(self):
            theSegment=self.segments[self.curSegment]
            # we have found all previous segments
            # try to find this segment directly after the next ones
            # or do we want to look at multiple previous segments here?
            
            
        def newColumnNames(self,names):
            names.extend(["magPos"])
            return names
            
    def mean(self,buf):
        sum=0.0
        count=0.0
        for c in buf:
            sum+=c
            count+=1.0
        if count==0.0:
            return 0.0
        else:
            return sum/count

    class debugProcessor1:
        def __init__(self,startTime,buf1,colName="dbg1"):
            self.colName=colName
            self.startTime=startTime
            self.pos=0
            self.buf1=buf1
            self.dir=1
        
        def processValues(self,values):
            curTime=values[0]
            val1=self.buf1[0]
            if curTime>self.startTime:
                if self.pos<len(self.buf1):
                    val1=self.buf1[self.pos]
                self.pos+=self.dir
                if self.pos>=len(self.buf1):
                    self.dir=-1
                    self.pos=len(self.buf1)-1
                    val1=0
                if self.pos<0:
                    self.dir=1
                    self.pos=0
                    val1=0
            values.append(val1)
            return values

        def newColumnNames(self,names):
            names.extend([self.colName])
            return names


            

class particleFilterFilter:
    def __init__(self,holder,selectionIn,selectionOut):
        self.holder=holder
        if selectionIn==None or selectionOut==None:
            return
        self.selectionIn=selectionIn
        self.selectionOut=selectionOut
        self.magneticDensityShape=[]
        self.magneticDensityColumn=holder.getColumnFromName("sqrt(mag_x^2+mag_y^2+mag_z^2)")
        values,minTime,maxTime=holder.getRange((selectionIn,selectionOut),self.magneticDensityColumn)
        for c in values:
            self.magneticDensityShape.append(c)
        self.magneticDensityLengthMultiplier=1.0 / len(self.magneticDensityShape)
        
        # smoothing (non-biased so we don't have a shift)
        smoothingLen=500
        smoother=deque(maxlen=smoothingLen)
        
        self.smoothedMagneticDensity=[]
        # first, add half as many values to the buffer
        # then for each sample we take mean of the buffer
        # and add another sample
        for c in self.magneticDensityShape[0:smoothingLen/2]:
            smoother.append(c)
        for c in self.magneticDensityShape[smoothingLen/2:]:
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.append(c)
        for c in range(0,smoothingLen/2):
            self.smoothedMagneticDensity.append(self.mean(smoother))
            smoother.popleft()
        print "PF:",len(self.smoothedMagneticDensity),len(self.magneticDensityShape)
        self.holder.runProcess(self.particleFilterProcessor(self.smoothedMagneticDensity,self.magneticDensityColumn,holder.getColumnFromName("forwards_mpsps"),holder.getColumnFromName("legangle_degrees")))
            
    def mean(self,buf):
        sum=0.0
        count=0.0
        for c in buf:
            sum+=c
            count+=1.0
        if count==0.0:
            return 0.0
        else:
            return sum/count
        


            
    class particleFilterProcessor:

        class particle:
            def __init__(self,acceleration=0,velocity=0,position=None):
                self.acceleration=acceleration
                self.velocity=velocity
                if position==None:
                    self.position=random.uniform(0,1)
                else:
                    self.position=position
                
            def reset(self):
                self.acceleration=0
                self.velocity=0
#                self.position=0
                self.position=random.uniform(0,1)
                
            def score(self,magnetic,accel,bodyAngle,poolProfile):
                pos=int(self.position*(len(poolProfile)-1))
                magDiff=magnetic - poolProfile[pos]
                magDiff*=magDiff
                accelDiff=(accel-self.acceleration)
                accelDiff*=accelDiff
    #            if bodyAngle>40 or bodyAngle<40:
    #                # score worse if it is moving fast whilst body is steep
                return 1.0/(magDiff+accelDiff)
                
            def updateParticleObject(self,dt,other):
                # assume 2.5 metres per second as a maximum possible speed
                # and that we might go from 0 that in 2 seconds
                newAcceleration=random.normalvariate(0,1.0)
                newVelocity=self.velocity+newAcceleration*dt
                newPos=self.position+dt*newVelocity
                if newPos>1.0: 
                    newPos=1.0
                    newVelocity=(newPos-self.position)/dt
                    newAcceleration=(self.velocity-newVelocity)/dt
                if newPos<0.0: 
                    newPos=0.0
                    newVelocity=(newPos-self.position)/dt
                    newAcceleration=(self.velocity-newVelocity)/dt
                other.acceleration=newAcceleration
                other.velocity=newVelocity
                other.position=newPos
    
    
        def __init__(self,poolProfile,magneticCol,accelCol,bodyAngleCol):
            self.poolProfile,self.magneticCol,self.accelCol,self.bodyAngleCol=(poolProfile,magneticCol,accelCol,bodyAngleCol)
            self.particles=[]
            self.particles2=[]
            self.cumulativeScores=[]
            self.totalScore=0
            self.initParticles(100)
            self.lastTime=None
            self.lastSecond=None
            
        def processValues(self,values):
            curTime=values[0]
            magnetic=values[self.magneticCol]
            accel=values[self.accelCol]
            bodyAngle=values[self.bodyAngleCol]
            outVal=0
            if self.lastTime!=None:
                dt=curTime-self.lastTime
#                t1=time.clock()
                self.scoreParticles(magnetic,accel,bodyAngle,self.poolProfile)
                outVal=self.getOutputValue()
#                t2=time.clock()
                self.generateNewParticles(dt)
#                t3=time.clock()
#                print t2-t1,t3-t2
                if self.lastSecond!=int(curTime):
                    print ".",outVal,self.particles2[0][1]
            values.append(outVal)
            self.lastTime=curTime
            self.lastSecond=int(curTime)
            return values

        def newColumnNames(self,names):
            names.extend(["dbg1"])
            return names
        
        def initParticles(self,numParticles):
            for c in range(0,numParticles):
                self.particles.append([self.particle(),0])
                self.particles2.append([self.particle(),0])
                self.cumulativeScores.append([0])
            
        def scoreParticles(self,magnetic,accel,bodyAngle,poolProfile):
            for c in range(0,len(self.particles)):
                score=self.particles[c][0].score(magnetic,accel,bodyAngle,poolProfile)
                self.particles[c][1]=score
            self.particles.sort(key=lambda (particle,score):-score)
            
            self.totalScore=0
            for c in range(0,len(self.particles)):
                score=self.particles[c][1]                
                self.totalScore+=score
                self.cumulativeScores[c]=self.totalScore
            
        def generateNewParticles(self,dt):
            numParticles=len(self.particles)            
            #5% of particles are brand new ones to seed if we are completely off track
            partArray=self.particles2
            for c in range(0,numParticles/20):
                partArray[c][0].reset()
            for c in range(numParticles/20,numParticles):
                selector=random.uniform(0,self.totalScore)
                pos=bisect.bisect_left(self.cumulativeScores,selector)
                self.particles[pos][0].updateParticleObject(dt,self.particles2[c][0])
            temp=self.particles2
            self.particles2=self.particles
            self.particles=temp
        
        def getOutputValue(self):
            return self.particles[0][0].position