# TODO: reprocess fwd movement value using both lin_x and lin_y/lin_z and see if we get anything better
#       or maybe even using ||lin_x,lin_y,lin_z|| if it isn't too buggered by rotation

#
# drag = velocity squared 
#
#
# profile of stroke like:
# pull   recover pull
# |------       -------|
#        -------
# TODO: 
# 1)try and identify interesting points using auto-marker algorithms
# 2)eg. can we identify 'strokes' in crawl?, can we identify turns in crawl?
# 3)can we break down the stroke into sub-parts - nb. once we have stroke markers we need to use these in 
#   our marker processing
# 4)record some more data - maybe from other people too.
#

# swimming todo:
# 1) swim with very very long glides and see what it does eg. 2 second glides
# 2) swim with low rotation
# 3) swim 


# Tune marker detection for breaststroke - take average amounts and detect a spike above it, and also detect a certain period of flat swimming before it (both ways flat), to avoid catching every push off as being a breaststroke kick 

# better definition of efficiency needed 


from collections import deque
from operator import add,mul        

import math
import numpy
import mdp

class ica:
    class addColumns:
        def __init__(self,valArray):
            self.valArray=valArray
            self.arrayPos=0
            self.columns=valArray.shape[1]
            
        def processValues(self,values):
            if self.arrayPos<len(self.valArray):
                for c in range(0,self.columns):
                    values.append(self.valArray[self.arrayPos][c])
            else:
                for c in range(0,self.columns):
                    values.append(0)
            self.arrayPos+=1
            return values

        def newColumnNames(self,names):
            for c in range(0,self.columns):
                names.append("ica_%d"%(c+1))
            return names

    def __init__(self,columns,holder):
        self.holder=holder
        self.values,startTime,endTime=holder.getRange((holder.getMinTime(),holder.getMaxTime()),columns)
        print self.values
        numValues=len(self.values)
        numColumns=len(columns)
        print numValues
        print numColumns
        self.bigArray=numpy.empty((numValues,numColumns))        
        columnNames=map(holder.getColumnName,columns)
        num=0
        for v in self.values:            
            for d in range(0,numColumns):
                self.bigArray[num][d]=v[columnNames[d]]
            num+=1
        print self.bigArray
        self.newArray=mdp.pca(self.bigArray)
        holder.runProcess(ica.addColumns(self.newArray))


class quadRegressionBuffer:
    def __init__(self,smoothingLen):
        self.buffer=deque(maxlen=smoothingLen)
        self.bufferSum=0
        self.smoothingLen=smoothingLen
        self.sumXXXX=0.0
        self.sumXXY=0.0
        self.sumXXX=0.0
        self.sumXX=0.0
        self.sumXY=0.0
        self.sumX=0.0
        self.sumY=0.0
        self.nDivisor=0
 #       self.firstX=None
        
    # add value time,value
    def addValue(self,x,y):
#        if self.firstX==None:
#            self.firstX=x
#        x-=self.firstX

#        self.sumXY+=x*y
#        self.sumXX+=x*x
#        self.sumY+=y
#        self.sumX+=x
#        self.sumXXXX+=x*x*x*x
#        self.sumXXY+=x*x*y
#        self.sumXXX+=x*x*x

#        if len(self.buffer)==self.smoothingLen:
#            ox=self.buffer[0][0]
#            oy=self.buffer[0][1]
#            self.sumXY-=ox*oy
#            self.sumXX-=ox*ox
#            self.sumY-=oy
#            self.sumX-=ox
#            self.sumXXXX-=ox*ox*ox*ox
#            self.sumXXY-=ox*ox*oy
#            self.sumXXX-=ox*ox*ox
        self.buffer.append((x,y))


        self.sumXXXX=reduce(add,map(lambda (x,y):x*x*x*x,self.buffer))
        self.sumXXY=reduce(add,map(lambda (x,y):x*x*y,self.buffer))
        self.sumXXX=reduce(add,map(lambda (x,y):x*x*x,self.buffer))
        self.sumXY=reduce(add,map(lambda (x,y):x*y,self.buffer))
        self.sumX=reduce(add,map(lambda (x,y):x,self.buffer))
        self.sumY=reduce(add,map(lambda (x,y):y,self.buffer))

        if len(self.buffer)<3:
            return 0,0,0
        else:
            n=float(len(self.buffer))
            divisor=(n*self.sumXX*self.sumXXXX - self.sumX*self.sumX*self.sumXXXX - n*self.sumXXX*self.sumXXX + 2.0*self.sumX*self.sumXX*self.sumXXX - self.sumXX*self.sumXX*self.sumXX)
            
            if divisor==0:
#                print n
                return 0,0,0
                
        
            a = (self.sumY*self.sumX*self.sumXXX - self.sumXY*n*self.sumXXX - self.sumY*self.sumXX*self.sumXX + self.sumXY*self.sumX*self.sumXX + self.sumXXY*n*self.sumXX - self.sumXXY*self.sumX*self.sumX)/divisor
            
            #(self.sumY*self.sumX*self.sumXXX - self.sumXY*n*self.sumXXX - self.sumY*self.sumXX*self.sumXX + self.sumXY*self.sumX*self.sumXX + self.sumXXY*n*self.sumXX - self.sumXXY*self.sumX*self.sumX)/divisor

            b = (self.sumXY*n*self.sumXXXX - self.sumY*self.sumX*self.sumXXXX + self.sumY*self.sumXX*self.sumXXX - self.sumXXY*n*self.sumXXX - self.sumXY*self.sumXX*self.sumXX + self.sumXXY*self.sumX*self.sumXX)/divisor

            c = (self.sumY*self.sumXX*self.sumXXXX - self.sumXY*self.sumX*self.sumXXXX - self.sumY*self.sumXXX*self.sumXXX + self.sumXY*self.sumXX*self.sumXXX + self.sumXXY*self.sumX*self.sumXXX - self.sumXXY*self.sumXX*self.sumXX)/divisor
            
#            (self.sumY*self.sumXX*self.sumXXXX - self.sumXY*self.sumX*self.sumXXXX - self.sumY*self.sumXXX*self.sumXXX + self.sumXY*self.sumXX*self.sumXXX + self.sumXXY*self.sumX*self.sumXXX - self.sumXXY*self.sumXX*self.sumXX)/divisor

        
#            divAB=((self.sumXX*self.sumXXXX)-(self.sumXXX*self.sumXXX))
#            a=((self.sumXXY*self.sumXX) - (self.sumXY*self.sumXXX))/ divAB
#            b=((self.sumXY*self.sumXXXX) -(self.sumXXY*self.sumXXX))/divAB
#            c=(self.sumY*nDiv) - ( b*(self.sumX*nDiv)) - (a*(self.sumXX*nDiv))
#            print self.sumY,self.sumX,self.sumXX,c,divAB
            return (c,b,a)
        
    def clear(self):
        self.buffer.clear()
        self.sumXX=0.0
        self.sumXY=0.0
        self.sumX=0
        self.sumY=0
        self.sumXXXX=0
        self.sumXXY=0
        self.sumXXX=0
        
        
class slopeBuffer:
    def __init__(self,smoothingLen,wantIntercept=False):
        self.buffer=deque(maxlen=smoothingLen)
        self.bufferSum=0
        self.smoothingLen=smoothingLen
        self.sumXX=0.0
        self.sumXY=0.0
        self.sumX=0.0
        self.sumY=0.0
        self.wantIntercept=wantIntercept
 #       self.firstX=None
        
    def addValue(self,curTime,curVal):
#        if self.firstX==None:
#            self.firstX=curTime
#        curTime-=self.firstX
        if len(self.buffer)==self.smoothingLen:
            self.sumXY-=self.buffer[0][0]*self.buffer[0][1]
            self.sumXX-=self.buffer[0][0]*self.buffer[0][0]
            self.sumY-=self.buffer[0][1]
            self.sumX-=self.buffer[0][0]
        self.buffer.append((curTime,curVal))
        self.sumXX+=curTime*curTime
        self.sumXY+=curTime*curVal
        self.sumY+=curVal
        self.sumX+=curTime
        if self.wantIntercept:
            if len(self.buffer)==1:
                return 0,0
            else:
                slope=(len(self.buffer)*self.sumXY -self.sumX*self.sumY)/(len(self.buffer)*self.sumXX - self.sumX*self.sumX)
                intercept=(self.sumY-slope*self.sumX)/len(self.buffer)
                return (intercept,slope)
        else:
            if len(self.buffer)==1:
                return 0
            else:
                return (len(self.buffer)*self.sumXY -self.sumX*self.sumY)/(len(self.buffer)*self.sumXX - self.sumX*self.sumX)
        
    def clear(self):
        self.buffer.clear()
        self.sumXX=0.0
        self.sumXY=0.0
        self.sumX=0
        self.sumY=0


class medianBuffer:
    def __init__(self,bufferLen):
        self.buffer=deque(maxlen=bufferLen)
        self.medianPos=bufferLen/2
        
    def addValue(self,curVal):
        self.buffer.appendleft(curVal)
        return sorted(self.buffer)[len(self.buffer)/2]

        
class firBuffer:
    def __init__(self,coefficients):
        self.buffer=deque(maxlen=len(coefficients))
        for c in range(len(coefficients)):
            self.buffer.appendleft(0.0)
        self.coefficients=coefficients
        
    def addValue(self,curVal):
        self.buffer.appendleft(curVal)
        return reduce(add,map(mul,self.buffer,self.coefficients))

class iirBuffer:
    def __init__(self,coefficientsX,coefficientsY):
        # ignore 1 coefficient on Y1
        coefficientsY=coefficientsY[1:]
        self.bufferX=deque(maxlen=len(coefficientsX))
        self.bufferY=deque(maxlen=len(coefficientsY))
        for c in range(len(coefficientsX)):
            self.bufferX.appendleft(0.0)
        for c in range(len(coefficientsY)):
            self.bufferY.appendleft(0.0)
        self.coefficientsX=coefficientsX
        self.coefficientsY=coefficientsY
        
    def addValue(self,curVal):
        self.bufferX.appendleft(curVal)
        yVal=reduce(add,map(mul,self.bufferX,self.coefficientsX))
        yVal-=reduce(add,map(mul,self.bufferY,self.coefficientsY))
        self.bufferY.appendleft(yVal)
        return yVal
        
        
class averageBuffer:
    def __init__(self,smoothingLen):
        self.buffer=deque(maxlen=smoothingLen)
        self.bufferSum=0
        self.smoothingLen=smoothingLen
        
    def addValue(self,curVal):
        if len(self.buffer)==self.smoothingLen:
            self.bufferSum-=self.buffer[0]
        self.buffer.append(curVal)
        self.bufferSum+=curVal
        return self.bufferSum/len(self.buffer)
        
    def clear(self):
        self.buffer.clear()
        self.bufferSum=0
        
class timedStatBuffer:
    def __init__(self,bufferLen):
        self.buffer=deque(maxlen=bufferLen)
        self.bufferSum=0
        self.bufferLen=bufferLen
        
    def addValue(self,curTime,curVal):
        if len(self.buffer)==self.bufferLen:
            self.bufferSum-=self.buffer[0][1]
        self.buffer.appendleft((curTime,curVal))
        self.bufferSum+=curVal
        
    def getMean(self):        
        return self.bufferSum/len(self.buffer)
        
    def mostRecentTimeLessThan(self,value,ignore):
        for c in range(ignore,len(self.buffer)):
            if self.buffer[c][1]<value:
                return self.buffer[c][0]
    
    def mostRecentTimeGreaterThan(self,value,ignore):
        for c in range(ignore,len(self.buffer)):
            if self.buffer[c][1]>value:
                return self.buffer[c][0]

    # function takes arguments: time,value, lastReturnVal,args
    def runFunctionBetweenTimes(self,fromTime,toTime,theFunction):
        lastReturnVal=None
        for (theTime,value) in reversed(self.buffer):
            if theTime>fromTime and theTime<toTime:
                lastReturnVal=theFunction(theTime,value)
        return lastReturnVal
            
    
class magnitudeProcessor:
    def __init__(self,cols):
        self.columns=cols
        
    def processValues(self,values):                
        sum=0
        for colNum in self.columns:
            sum+=values[colNum]*values[colNum]
        sum=math.sqrt(sum)
        values.append(sum)
        return values

    def newColumnNames(self,names):
        str="sqrt("
        for colNum in self.columns:
            str+=names[colNum]+"^2+"
        str=str[:-1]
        str+=")"
        names.append(str)
        return names
        
class iirSmoothingProcessor:
    def __init__(self,column):
        self.column=column
        coefficientsX=[
        0.91671250709488528000,
        -1.83333091926828670000,
        0.91671250709488528000
        ]
        coefficientsY=[
        1.00000000000000000000,
        -1.98989496882199200000,
        0.98999709932602176000
        ]
        self.buffer=iirBuffer(coefficientsX,coefficientsY)
        
    def processValues(self,values):
        curVal = values[self.column]
        values.append(self.buffer.addValue(curVal))
        return values

    def newColumnNames(self,names):
        names.append(names[self.column]+"_smoothed")
        return names

        
        
class firSmoothingProcessor:
    def __init__(self,column):
        self.column=column
        coefficients=[        
        0.00008227492572143758,
        0.00012390658842054578,
        0.00016586760991379036,
        0.00020815791268741362,
        0.00025077742324248228,
        0.00029372607331799161,
        0.00033700380118891198,
        0.00038061055304336650,
        0.00042454628444305416,
        0.00046881096187255226,
        0.00051340456437711174,
        0.00055832708529958593,
        0.00060357853411856948,
        0.00064915893839116441,
        0.00069506834580946881,
        0.00074130682637400965,
        0.00078787447469099337,
        0.00083477141240359456,
        0.00088199779075593082,
        0.00092955379330775907,
        0.00097743963879776477,
        0.00102565558417281460,
        0.00107420192778705300,
        0.00112307901278004910,
        0.00117228723065063260,
        0.00122182702502811670,
        0.00127169889566090710,
        0.00132190340263173170,
        0.00137244117081342510,
        0.00142331289458112090,
        0.00147451934279246790,
        0.00152606136405918340,
        0.00157793989232374610,
        0.00163015595275936500,
        0.00168271066802044260,
        0.00173560526485823480,
        0.00178884108113238420,
        0.00184241957324051090,
        0.00189634232399659160,
        0.00195061105098825450,
        0.00200522761544329750,
        0.00206019403164731710,
        0.00211551247694401240,
        0.00217118530236696740,
        0.00222721504394098000,
        0.00228360443471394220,
        0.00234035641755868730,
        0.00239747415881621900,
        0.00245496106283940280,
        0.00251282078750265140,
        0.00257105726076328150,
        0.00262967469835103870,
        0.00268867762267775310,
        0.00274807088307065270,
        0.00280785967743465850,
        0.00286804957547139980,
        0.00292864654357622490,
        0.00298965697157167620,
        0.00305108770143239360,
        0.00311294605817636400,
        0.00317523988312948730,
        0.00323797756977069670,
        0.00330116810240605950,
        0.00336482109793901630,
        0.00342894685103511950,
        0.00349355638301630370,
        0.00355866149485318000,
        0.00362427482467608160,
        0.00369040991026785840,
        0.00375708125706070890,
        0.00382430441223022580,
        0.00389209604554167010,
        0.00396047403770699410,
        0.00402945757708886390,
        0.00409906726571820060,
        0.00416932523571724060,
        0.00424025527736627840,
        0.00431188298023746020,
        0.00438423588901988050,
        0.00445734367590444340,
        0.00453123833166925450,
        0.00460595437795355890,
        0.00468152910358359850,
        0.00475800282829055240,
        0.00483541919770073130,
        0.00491382551414120280,
        0.00499327310859480450,
        0.00507381776007461050,
        0.00515552016984333930,
        0.00523844649928710110,
        0.00532266898194611730,
        0.00540826662228052500,
        0.00549532599631072720,
        0.00558394217243898900,
        0.00567421977471107340,
        0.00576627421572594580,
        0.00586023313267535880,
        0.00595623806792538670,
        0.00605444644577068840,
        0.00615503391013014560,
        0.00625819710509660770,
        0.00636415700277055600,
        0.00647316291267655430,
        0.00658549734711721180,
        0.00670148197112061490,
        0.00682148494015521240,
        0.00694593003242064380,
        0.00707530812866737340,
        0.00721019180190505400,
        0.00735125408453934060,
        0.00749929293365989100,
        0.00765526360244735220,
        0.00782032219216649560,
        0.00799588535800840190,
        0.00818371392839118730,
        0.00838603292263324570,
        0.00860570877852565030,
        0.00884651994171858390,
        0.00911358675110312230,
        0.00941408811269342850,
        0.00975852979751463440,
        0.01016316637443400900,
        0.01065511561554836000,
        0.01128478357000423400,
        0.01216316295243317600,
        0.01362389929181488100,
        0.01799190209588170900,
        0.01362389929181488100,
        0.01216316295243317600,
        0.01128478357000423400,
        0.01065511561554836000,
        0.01016316637443400900,
        0.00975852979751463440,
        0.00941408811269342850,
        0.00911358675110312230,
        0.00884651994171858390,
        0.00860570877852565030,
        0.00838603292263324570,
        0.00818371392839118730,
        0.00799588535800840190,
        0.00782032219216649560,
        0.00765526360244735220,
        0.00749929293365989100,
        0.00735125408453934060,
        0.00721019180190505400,
        0.00707530812866737340,
        0.00694593003242064380,
        0.00682148494015521240,
        0.00670148197112061490,
        0.00658549734711721180,
        0.00647316291267655430,
        0.00636415700277055600,
        0.00625819710509660770,
        0.00615503391013014560,
        0.00605444644577068840,
        0.00595623806792538670,
        0.00586023313267535880,
        0.00576627421572594580,
        0.00567421977471107340,
        0.00558394217243898900,
        0.00549532599631072720,
        0.00540826662228052500,
        0.00532266898194611730,
        0.00523844649928710110,
        0.00515552016984333930,
        0.00507381776007461050,
        0.00499327310859480450,
        0.00491382551414120280,
        0.00483541919770073130,
        0.00475800282829055240,
        0.00468152910358359850,
        0.00460595437795355890,
        0.00453123833166925450,
        0.00445734367590444340,
        0.00438423588901988050,
        0.00431188298023746020,
        0.00424025527736627840,
        0.00416932523571724060,
        0.00409906726571820060,
        0.00402945757708886390,
        0.00396047403770699410,
        0.00389209604554167010,
        0.00382430441223022580,
        0.00375708125706070890,
        0.00369040991026785840,
        0.00362427482467608160,
        0.00355866149485318000,
        0.00349355638301630370,
        0.00342894685103511950,
        0.00336482109793901630,
        0.00330116810240605950,
        0.00323797756977069670,
        0.00317523988312948730,
        0.00311294605817636400,
        0.00305108770143239360,
        0.00298965697157167620,
        0.00292864654357622490,
        0.00286804957547139980,
        0.00280785967743465850,
        0.00274807088307065270,
        0.00268867762267775310,
        0.00262967469835103870,
        0.00257105726076328150,
        0.00251282078750265140,
        0.00245496106283940280,
        0.00239747415881621900,
        0.00234035641755868730,
        0.00228360443471394220,
        0.00222721504394098000,
        0.00217118530236696740,
        0.00211551247694401240,
        0.00206019403164731710,
        0.00200522761544329750,
        0.00195061105098825450,
        0.00189634232399659160,
        0.00184241957324051090,
        0.00178884108113238420,
        0.00173560526485823480,
        0.00168271066802044260,
        0.00163015595275936500,
        0.00157793989232374610,
        0.00152606136405918340,
        0.00147451934279246790,
        0.00142331289458112090,
        0.00137244117081342510,
        0.00132190340263173170,
        0.00127169889566090710,
        0.00122182702502811670,
        0.00117228723065063260,
        0.00112307901278004910,
        0.00107420192778705300,
        0.00102565558417281460,
        0.00097743963879776477,
        0.00092955379330775907,
        0.00088199779075593082,
        0.00083477141240359456,
        0.00078787447469099337,
        0.00074130682637400965,
        0.00069506834580946881,
        0.00064915893839116441,
        0.00060357853411856948,
        0.00055832708529958593,
        0.00051340456437711174,
        0.00046881096187255226,
        0.00042454628444305416,
        0.00038061055304336650,
        0.00033700380118891198,
        0.00029372607331799161,
        0.00025077742324248228,
        0.00020815791268741362,
        0.00016586760991379036,
        0.00012390658842054578,
        0.00008227492572143758
]
        self.buffer=firBuffer(coefficients)
        
    def processValues(self,values):
        curVal = values[self.column]
        values.append(self.buffer.addValue(curVal))
        return values

    def newColumnNames(self,names):
        names.append(names[self.column]+"_smoothed")
        return names
        

class medianSmoothingProcessor:
    def __init__(self,column,smoothingLen):
        self.column=column
        self.buffer=medianBuffer(smoothingLen)
        
    def processValues(self,values):
        curVal = values[self.column]
        values.append(self.buffer.addValue(curVal))
        return values

    def newColumnNames(self,names):
        names.append(names[self.column]+"_smoothed")
        return names

        
class smoothingProcessor:
    def __init__(self,column,smoothingLen):
        self.column=column
        self.buffer=averageBuffer(smoothingLen)
        
    def processValues(self,values):
        curVal = values[self.column]
        values.append(self.buffer.addValue(curVal))
        return values

    def newColumnNames(self,names):
        names.append(names[self.column]+"_smoothed")
        return names

class slopeProcessor:
    def __init__(self,column,smoothingLen):
        self.column=column
        self.buffer=slopeBuffer(smoothingLen)
        self.timeColumn=0
        self.timeMultiplier=1
        
    def initHolder(self,holder):
        nanoCol=holder.getColumnFromName("nanotime")
        if nanoCol!=-1:
            self.timeColumn=nanoCol
            self.timeMultiplier=1.0/1000000000.0
        
    def processValues(self,values):
        curTime=values[self.timeColumn]*self.timeMultiplier
        curVal = values[self.column]
        values.append(self.buffer.addValue(curTime,curVal))
        return values

    def newColumnNames(self,names):
        names.append(names[self.column]+"_slope")
        return names

class linearSmoothingProcessor:
    def __init__(self,column,smoothingLen):
        self.column=column
        self.buffer=slopeBuffer(smoothingLen,True)
        self.smoothingLen=smoothingLen
        self.timeColumn=0
        self.timeMultiplier=1
        
    def initHolder(self,holder):
        nanoCol=holder.getColumnFromName("nanotime")
        if nanoCol!=-1:
            self.timeColumn=nanoCol
            self.timeMultiplier=1.0/1000000000.0
        
    def processValues(self,values):
        curVal = values[self.column]
        curTime=values[self.timeColumn]*self.timeMultiplier
        intercept,slope=self.buffer.addValue(curTime,curVal)
        valueHere = slope * curTime + intercept
        values.append(valueHere)
        return values

    def newColumnNames(self,names):
        names.append(names[self.column]+"_smoothed")
        return names
        
class quadraticSmoothingProcessor:
    def __init__(self,column,smoothingLen):
        self.column=column
        self.buffer=quadRegressionBuffer(smoothingLen)
        self.timeColumn=0
        self.timeMultiplier=1
        
    def initHolder(self,holder):
        nanoCol=holder.getColumnFromName("nanotime")
        if nanoCol!=-1:
            self.timeColumn=nanoCol
            self.timeMultiplier=1.0/1000000000.0
        
    def processValues(self,values):
        curVal = values[self.column]
        curTime=values[self.timeColumn]*self.timeMultiplier
        c,b,a=self.buffer.addValue(curTime,curVal)
        valueHere = a* curTime*curTime + b * curTime + c
#        print "a=",a,"b=",b,"c=",c,"valDiff=",valueHere-curVal,curVal
        values.append(valueHere)
        return values

    def newColumnNames(self,names):
        names.append(names[self.column]+"_smoothed")
        return names
        
class acceptFlatValuesProcessor:
    def __init__(self,rollCol,cutoff,bodyCol,filterCol):
        self.rollCol=rollCol
        self.filterCol=filterCol
        self.bodyCol=bodyCol
        self.curValue=0
        self.cutoff=cutoff
        self.lastValue=0
        self.lastValue2=0
        self.stopped=True
        self.lastFilter=0
        
    def processValues(self,values):
        if abs(values[self.bodyCol])<40:
            if  self.stopped==True:
                self.stopped=False
                self.curValue=values[self.filterCol]
        else:
            self.stopped=True
        rollVal=values[self.rollCol]
        if not self.stopped and abs(values[self.rollCol])<self.cutoff:
            if abs(self.lastValue)<abs(rollVal) and abs(self.lastValue2)>abs(self.lastValue):
                self.curValue=self.lastFilter
        values.append(self.curValue)
        self.lastValue2=self.lastValue
        self.lastValue=rollVal
        self.lastFilter=values[self.filterCol]
        return values
    
    def newColumnNames(self,names):
        names.append(names[self.filterCol]+"_flat")
        return names

class minMaxMidpointProcessor:
    def __init__ (self,column,minTimePerHalfCycle):
        self.column=column
        self.minTime=minTimePerHalfCycle
        self.timeColumn=0
        self.timeMultiplier=1.0
        self.lastTime=None
        self.lastValue=None
        self.direction=None
        self.lastCycleTime=None
        self.lastButOneCycleTime=None
        self.lastMinimum=None
        self.lastMaximum=None
        self.curMinimum=None
        self.curMaximum=None
        self.lastRange=1.0

    def initHolder(self,holder):
        nanoCol=holder.getColumnFromName("nanotime")
        if nanoCol!=-1:
            self.timeColumn=nanoCol
            self.timeMultiplier=1.0/1000000000.0
        
    def processValues(self,values):                
        thisTime=float(values[self.timeColumn])*self.timeMultiplier
        thisValue=values[self.column]
        if self.lastValue==None:
            self.lastValue=thisValue
            self.lastMaximum=thisValue
            self.lastMinimum=thisValue
            self.lastCycleTime=thisTime
            self.lastButOneCycleTime=thisTime
            self.lastCycleValue=0.5*(self.lastMaximum+self.lastMinimum)
            self.curMinimum=thisValue
            self.curMaximum=thisValue
        elif self.direction==None:
            # set initial direction
            if self.lastValue<thisValue:
                self.direction=1
            else:
                self.direction==-1
        else:
            # finding max / minimums
            thisDirection=0
            if self.lastValue>thisValue:
                thisDirection=-1
            elif self.lastValue<thisValue:
                thisDirection=1            
                
            if self.direction==1:
                self.curMaximum=max(thisValue,self.curMaximum)
#                print self.curMaximum,thisValue,self.lastRange,self.direction
                if thisTime-self.lastCycleTime>self.minTime and (self.curMaximum-thisValue)>self.lastRange*0.2:
                    self.direction=-1
                    self.lastMaximum=self.curMaximum
                    self.lastCycleValue=0.5*(self.lastMaximum+self.lastMinimum)
                    self.lastRange=self.lastMaximum-self.lastMinimum
                    self.curMinimum=thisValue
                    self.lastCycleTime=thisTime
            elif self.direction==-1:
#                print self.curMinimum,thisValue,self.lastRange,self.direction
                self.curMinimum=min(thisValue,self.curMinimum)
                if thisTime-self.lastCycleTime>self.minTime and (thisValue-self.curMinimum)>self.lastRange*0.2:
                    self.lastMinimum=self.curMinimum
                    self.direction=1
                    self.lastCycleValue=0.5*(self.lastMaximum+self.lastMinimum)
                    self.lastRange=self.lastMaximum-self.lastMinimum
                    self.curMaximum=thisValue
                    self.lastCycleTime=thisTime
        values.append(self.lastCycleValue)
        self.lastValue=thisValue
        return values
        
        
    def newColumnNames(self,names):
        names.append(names[self.column]+"_mid")
        return names
        
        
class accelerationProcessor:
    def __init__(self,col1,col2,col3):
        self.columns=(col1,col2,col3)
        
    def processValues(self,values):                
        sum=0
        for colNum in self.columns:
            sum+=values[colNum]*values[colNum]
        sum=math.sqrt(sum) -9.81
        values.append(sum)
        return values

    def newColumnNames(self,names):
        str="sqrt("
        for colNum in self.columns:
            str+=names[colNum]+"^2 +"
        str=str[:-1]
        str+=")"
        names.append(str)
        return names


class cleverSpeedProcessor:
    def __init__(self,accelCol,directionCol,legAngleCol,poolDirection):
        self.accelCol=accelCol
        self.directionCol=directionCol
        self.legAngleCol=legAngleCol
        self.poolDirection=poolDirection
        self.lastValue=0       
        self.lastTime=None
        self.timeColumn=0
        self.timeMultiplier=1
        self.accelHistory=deque(maxlen=1000)
        self.directionHistory=deque(maxlen=1000)
        self.legAngleHistory=deque(maxlen=1000)
        self.dtHistory=deque(maxlen=1000)
        self.stopped=False
        self.poolPos=0.0
        
    def initHolder(self,holder):
        nanoCol=holder.getColumnFromName("nanotime")
        if nanoCol!=-1:
            self.timeColumn=nanoCol
            self.timeMultiplier=1.0/1000000000.0
        
    def processValues(self,values):                
        thisTime=float(values[self.timeColumn])*self.timeMultiplier
        curAccel=values[self.accelCol]
        curDirection=values[self.directionCol]
        curLegAngle=values[self.legAngleCol]
        if self.lastTime==None:
            self.lastValue=0
        else:
            diffTime=thisTime-self.lastTime
            if curLegAngle>40:  
                # stopped - assume zero speed
                self.lastValue=0
                self.poolPos=0
                if not self.stopped:
                    self.legAngleHistory.clear()
                    self.directionHistory.clear()
                    self.accelHistory.clear()
                    self.dtHistory.clear()
                self.stopped=True
                self.legAngleHistory.append(curLegAngle)
                self.directionHistory.append(curDirection)
                self.accelHistory.append(curAccel)
                self.dtHistory.append(diffTime)
            else:
                # swimming - integrate speed
                if self.stopped:
                    # just started a length - check if there is any previous
                    # acceleration which we need to take account of
                    # since either: moment of turn (if we were swimming < 1000 data points ago)
                    #            or first point of verticality where we were
                    #            roughly pointing poolwards (if we started from the wall)
                    startedPos=len(self.legAngleHistory)
                    if len(self.legAngleHistory)<1000:
                        # look for a turn - where pool direction sharply changes                        
                        # and also go back until leg angle stops rising
                        lastLegAngle=curLegAngle
                        foundStart=False
                        curPos=len(self.legAngleHistory)-1
                        while (not foundStart) and curPos>0:
                            curPos-=1
                            thisAngle=self.legAngleHistory[curPos]
                            thisDirection=self.directionHistory[curPos]
                            if abs(thisAngle)<abs(lastLegAngle):
                                foundStart=True
                            directionDiff=abs(thisDirection-curDirection)
                            if directionDiff>math.pi:
                                directionDiff=2.0*math.pi - directionDiff
                            if abs(thisDirection - curDirection)>math.pi*0.25:
                                foundStart=True
                        if curPos>0:
                            startedPos=curPos
                    else:
                        # go back until leg angle stops rising, or direction goes off centre
                        lastLegAngle=curLegAngle
                        foundStart=False
                        curPos=len(self.legAngleHistory)-1
                        while (not foundStart) and curPos>0:
                            curPos-=1
                            thisAngle=self.legAngleHistory[curPos]
                            thisDirection=self.directionHistory[curPos]
                            if abs(thisAngle)<abs(lastLegAngle):
                                foundStart=True
                            directionDiff=abs(thisDirection-curDirection)
                            if directionDiff>math.pi:
                                directionDiff=2.0*math.pi - directionDiff
                            if abs(thisDirection - curDirection)>math.pi*0.25:
                                foundStart=True
                        if curPos>0:
                            startedPos=curPos
                    self.lastValue=0
                    for c in range(startedPos,len(self.legAngleHistory)):
                        self.lastValue=self.lastValue+ (self.accelHistory[c]*self.dtHistory[c])
                        self.poolPos+=self.lastValue*self.dtHistory[c]
                    print len(self.legAngleHistory)-startedPos
                    self.stopped=False
                self.lastValue= self.lastValue+ (curAccel*(diffTime))
                self.poolPos+=self.lastValue*diffTime
        values.append(self.lastValue)
        values.append(self.poolPos)
        self.lastTime=thisTime
        return values
        
    def newColumnNames(self,names):
        names.append(names[self.accelCol]+"_speed")
        names.append(names[self.accelCol]+"_pos")
        return names

        
class integratingProcessor:
    def __init__(self,column):
        self.column=column
        self.lastValue=0       
        self.lastTime=None
        self.timeColumn=0
        self.timeMultiplier=1
        
    def initHolder(self,holder):
        nanoCol=holder.getColumnFromName("nanotime")
        if nanoCol!=-1:
            self.timeColumn=nanoCol
            self.timeMultiplier=1.0/1000000000.0
        
    def processValues(self,values):                
        thisTime=float(values[self.timeColumn])*self.timeMultiplier
        if self.lastTime!=None:
            diffTime=thisTime-self.lastTime
            self.lastValue= self.lastValue+ (values[self.column]*(diffTime))
        else:
            self.lastValue=0
        values.append(self.lastValue)
        self.lastTime=thisTime
        return values
        
    def newColumnNames(self,names):
        names.append(names[self.column]+"_integrated")
        return names

class derivativeProcessor:
    def __init__(self,column):
        self.column=column
        self.lastValue=0       
        self.lastTime=None
        self.timeColumn=0
        self.timeMultiplier=1
        self.lastDerivative=None
        
    def initHolder(self,holder):
        nanoCol=holder.getColumnFromName("nanotime")
        if nanoCol!=-1:
            self.timeColumn=nanoCol
            self.timeMultiplier=1.0/1000000000.0
        
    def processValues(self,values):                
        thisTime=float(values[self.timeColumn])*self.timeMultiplier
        thisValue=values[self.column]
        if self.lastTime!=None:
            if self.lastValue!=thisValue:
                diffTime=thisTime-self.lastTime
                derivative=(thisValue-self.lastValue)/diffTime
                derivative=self.lastDerivative*0.8 + derivative*0.2
                self.lastValue=thisValue
                self.lastTime=thisTime
            else:
                # exactly the same value - this is just a sensor that doesn't report this quickly
                derivative=self.lastDerivative
        else:
            derivative=0
            self.lastValue=thisValue
            self.lastTime=thisTime
        values.append(derivative)
        self.lastDerivative=derivative
        return values
        
    def newColumnNames(self,names):
        names.append(names[self.column]+"_derivative")
        return names

        
# find and mark crawl and breast-strokes
# and inter-stroke measurements
class findStrokeProcessor:
    def __init__(self):
        self.maxRoll=0
        self.lastIdentifiedRoll=0
        self.inBSAcceleration=False
        self.maxBSAcceleration=0
        self.crawlMarkers=[]
        self.bsMarkers=[]
        self.crawlEfficiencyMarkers=[]
        self.inStart=False
        self.startPushed=False
        self.startLevel=False
        self.startMarkers=[]       
        self.fwdSmoother1=averageBuffer(64)
        
        self.accelerationAmount=0
        self.accelerationCount=0
        self.crawlLastStroke=None
        self.lastTime=None
        self.crawlStrokeMarked=False
        self.crawlEfficiencyAccumulator=None

        self.rollHistory=timedStatBuffer(8192)
        self.fwdHistoryIntegrated=timedStatBuffer(8192)
        self.fwdHistory=timedStatBuffer(8192)
        
    class findMinMaxCompensatingForSlope:    
        def __init__(self,slope):
            self.slope=slope
            self.slopeAccumulator=0
            self.prevTime=None
            self.minVal=None
            self.maxVal=None

        def fn(self,curTime,value):
            if self.prevTime==None:
                self.minVal=0
                self.maxVal=0
                self.slopeAccumulator=value
            else:
                dt=curTime-self.prevTime
                self.slopeAccumulator+=dt*self.slope
                curVal=value - self.slopeAccumulator
                self.minVal=min(self.minVal,curVal)
                self.maxVal=max(self.maxVal,curVal)
            self.prevTime=curTime
            return (self.minVal,self.maxVal)

    class findVarianceCompensatingForSlope:    
        def __init__(self,slope):
            self.slope=slope
            self.slopeAccumulator=0
            self.prevTime=None
            self.minVal=None
            self.maxVal=None
            
            self.n=0
            self.mean=0
            self.M2=0
            
        def fn(self,curTime,value):
            if self.prevTime==None:
                self.minVal=0
                self.maxVal=0
                self.slopeAccumulator=value
                curVal=0
            else:
                dt=curTime-self.prevTime
                self.slopeAccumulator+=dt*self.slope
                curVal=value - self.slopeAccumulator

            self.n = self.n + 1
            delta = curVal - self.mean
            self.mean = self.mean + delta/self.n
            self.M2 = self.M2 + delta*(curVal - self.mean)

            self.prevTime=curTime
            return (self.M2,self.n)


    class findVariance:    
        def __init__(self):
            self.prevTime=None
            
            self.n=0
            self.mean=0
            self.M2=0
            
        def fn(self,curTime,value):
            curVal=value

            self.n = self.n + 1
            delta = curVal - self.mean
            self.mean = self.mean + delta/self.n
            self.M2 = self.M2 + delta*(curVal - self.mean)

            self.prevTime=curTime
            return (self.M2,self.n)


            
    class findStartEnd:
        def __init__(self):
            self.lastVal=None
            
        def fn(self,curTime,value):
            if self.lastVal==None:
                self.lastVal= (value,value)
            else:
                self.lastVal=(self.lastVal[0],value)
            return self.lastVal
            
    class findAccelAmountsSquared:
        def __init__(self):
            self.total=0
            self.prevTime=None

        def fn(self,curTime,value):
            if self.prevTime!=None:
                dt=curTime-self.prevTime
                self.total+=(value*value)*dt
            self.prevTime=curTime
            return self.total
            
        
    def calcEfficiencyValues(self,timeFrom,timeTo,accumulator):
        if accumulator!=None:
            (strokeCount,efficiencyTotal,timeTotal)=accumulator
        else:
            (strokeCount,efficiencyTotal,timeTotal)=(0,0,0)        
        strokeDelta=timeTo-timeFrom
        (startVal,endVal)=self.fwdHistoryIntegrated.runFunctionBetweenTimes(timeFrom,timeTo,self.findStartEnd().fn)
        slope=(endVal-startVal)/(timeTo-timeFrom)
        (minVal,maxVal)=self.fwdHistoryIntegrated.runFunctionBetweenTimes(timeFrom,timeTo,self.findMinMaxCompensatingForSlope(slope).fn)
#        (M2,n)=self.fwdHistoryIntegrated.runFunctionBetweenTimes(timeFrom,timeTo,self.findVarianceCompensatingForSlope(slope).fn)
#        (M2,n)=self.fwdHistory.runFunctionBetweenTimes(timeFrom,timeTo,self.findUps().fn)
#        variance=M2/(n+1)
        variance=self.fwdHistory.runFunctionBetweenTimes(timeFrom,timeTo,self.findAccelAmountsSquared().fn)

        print minVal,maxVal,variance
        efficiency=variance
        strokeCount+=1
        efficiencyTotal+=variance
        timeTotal+=strokeDelta
        self.crawlEfficiencyMarkers.append((timeFrom,(0,0,0),"strokes%d\nt:%f(%f)\nsr:%f(%f)\neff:%f(%f)"%(strokeCount,strokeDelta,timeTotal,60/(strokeDelta),60/(timeTotal/strokeCount),efficiency,efficiencyTotal/strokeCount),timeTo))
        return (strokeCount,efficiencyTotal,timeTotal)
        
    def processValues(self,values):
        rollVal=values[1]
        legVal=values[2]
        fwdAccel=values[3]
        fwdIntegrated=values[-1]

        self.rollHistory.addValue(values[0],rollVal)
        self.fwdHistoryIntegrated.addValue(values[0],fwdIntegrated)
        self.fwdHistory.addValue(values[0],fwdAccel)

        fwdSmoothed=self.fwdSmoother1.addValue(fwdAccel)
        if legVal>60:
            if not self.inStart:
                self.inStart=True
                self.startLevel=False
                self.startPushed=False
                self.startMarkers.append((values[0],(255,255,0),"stopped"))
        if self.inStart:
            if legVal<40 and fwdSmoothed>0.5 and not self.startPushed:
                self.startPushed=True
                self.startMarkers.append((values[0],(255,0,255),"pushed"))
            if legVal<10 and legVal>-10 and rollVal<10 and rollVal>-10:
                if not self.startLevel:
                    self.startLevel=True
                    self.startMarkers.append((values[0],(0,255,255),"start level"))
                # after leg dip, we could roll either way
                self.lastIdentifiedRoll=0
            if self.startPushed and self.startLevel:
                self.inStart=False
        else:
            if self.lastTime!=None:
                self.accelerationAmount=float(self.accelerationAmount)+abs(fwdAccel)
                self.accelerationCount+=values[0]-self.lastTime
            self.lastTime=values[0]

            # crawl detection
            # legs high enough that we are believably swimming and not stopped on the wall
            if legVal<40 and legVal>-40:               
                #first identify which side we are rolled to, and what the maximum roll is
                if self.lastIdentifiedRoll!=-1 and rollVal<-20:
                    self.crawlStrokeMarked=False
                    self.lastIdentifiedRoll=-1
                    self.maxRoll=rollVal
                elif self.lastIdentifiedRoll!=1 and rollVal>20:
                    self.crawlStrokeMarked=False
                    self.maxRoll=rollVal
                    self.lastIdentifiedRoll=1
                elif self.lastIdentifiedRoll==1 and rollVal>self.maxRoll:
                    self.maxRoll=rollVal
                elif self.lastIdentifiedRoll==-1 and rollVal<self.maxRoll:
                    self.maxRoll=rollVal
                    
                # if we are in a roll, and have yet to mark the stroke, then wait until we are at 0.8 x maxRoll    
                # when we reach that point, mark the stroke as being the midpoint in time between
                # the point where the roll first reached 0.8 x maxroll and the last point where it reached it
                # (the roll-in and roll-out time)
                if self.lastIdentifiedRoll==1 and rollVal<self.maxRoll*0.8 and self.crawlStrokeMarked==False:
                    self.crawlStrokeMarked=True
                    rollOutTime=values[0]
                    rollInTime=self.rollHistory.mostRecentTimeLessThan(rollVal,1)
                    strokeTime=(rollInTime+rollOutTime)*0.5
                    self.crawlMarkers.append((strokeTime,(255,0,0),"crawlL"))
                    if self.crawlLastStroke!=None:
                        self.crawlEfficiencyAccumulator=self.calcEfficiencyValues(self.crawlLastStroke,strokeTime,self.crawlEfficiencyAccumulator)
                    self.crawlLastStroke=strokeTime
                if self.lastIdentifiedRoll==-1 and rollVal>self.maxRoll*0.8 and self.crawlStrokeMarked==False:
                    self.crawlStrokeMarked=True
                    rollOutTime=values[0]
                    rollInTime=self.rollHistory.mostRecentTimeGreaterThan(rollVal,1)
                    strokeTime=(rollInTime+rollOutTime)*0.5
                    self.crawlMarkers.append((strokeTime,(0,255,0),"crawlR"))
                    if self.crawlLastStroke!=None:
                        self.crawlEfficiencyAccumulator=self.calcEfficiencyValues(self.crawlLastStroke,strokeTime,self.crawlEfficiencyAccumulator)
                    self.crawlLastStroke=strokeTime                    
            else:                
                # after leg dip, we could roll either way
                self.lastIdentifiedRoll=0
                self.crawlLastStroke=None
                self.crawlEfficiencyAccumulator=None
                
            # breaststroke detec    tion - look for propulsion whilst not being on the side
            # DISABLED RIGHT NOW
            if legVal<40 and legVal>-40 and False:
                # actually swimming
                if rollVal<10 and rollVal>-10:                    
                    #not rolling side to side
                    if fwdAccel>2.0:
                        # decent amount of acceleration - must be a BS leg kick
                        if not self.inBSAcceleration:
                            self.inBSAcceleration=True                            
                            self.maxBSAcceleration=fwdAccel
                            self.bsMarkers.append((values[0],(0,0,255),"bsKick"))
                        elif fwdAccel>self.maxBSAcceleration:
                            self.maxBSAcceleration=fwdAccel
                            self.bsMarkers[-1]=(values[0],(0,0,255),"bsKick")
                    else:
                        self.inBSAcceleration=False
                        self.maxBSAcceleration=0.0                    
        return values
    
    def newMarkers(self):            
        return self.crawlMarkers+self.crawlEfficiencyMarkers+self.bsMarkers+self.startMarkers
   
class orientedMagneticProcessor:
    def __init__(self,orientationCols,magneticCols,startingTime,endingTime):
        self.orientationCols=orientationCols
        self.magneticCols=magneticCols        
        self.startingTime=startingTime
        self.endingTime=endingTime
        self.counter=0
        self.lastRoll=0
        self.lastRoll2=0
        self.curValues=[0.0,0.0,0.0]
        self.lastXYZ=[0,0,0]
        
    def processValues(self,values):   
        if values[0]<self.startingTime or values[0]>self.endingTime:
            values.extend([0.0,0.0,0.0])
        else:
            yaw,pitch,roll = values[self.orientationCols[0]],values[self.orientationCols[1]],values[self.orientationCols[2]]
            x,y,z =values[self.magneticCols[0]],values[self.magneticCols[1]],values[self.magneticCols[2]]
            self.curValues=self.rotatePitch((x,y,z),pitch)            
            self.counter+=1
            if self.counter==1000:
                print "."
                self.counter=0
#            if roll<0.1 and abs(self.lastRoll)<abs(roll) and abs(self.lastRoll2)>abs(self.lastRoll):
#                yaw=0
#                pitch=0
#                roll=0
#                
#                x,y,z=self.lastXYZ##

#                self.curValues=self.rotateVector((x,y,z),yaw,pitch,roll)
#                self.counter+=1
#                if self.counter==1000:
#                    print "."
#                    self.counter=0
            values.extend(self.curValues)
#            self.lastXYZ=values[self.magneticCols[0]],values[self.magneticCols[1]],values[self.magneticCols[2]]
#            self.lastRoll2=self.lastRoll
#            self.lastRoll=roll
        return values

    def rotatePitch(self,magValues,pitch):
        vector=numpy.matrix([magValues])
        cp=math.cos(pitch)
        sp=math.sin(pitch)
        pitchMatrix=numpy.matrix([[1,0,0],
                   [0,cp,-sp],
                   [0,sp,cp]])
        vector=vector*((pitchMatrix))
        vector=vector.tolist()[0]
        return vector
        
        
    def rotateVector(self,magValues,yaw,pitch,roll):
        vector=numpy.matrix([magValues])
        # yaw
        cy=math.cos(yaw)
        sy=math.sin(yaw)
        yawMatrix=numpy.matrix([[cy,-sy,0],
           [sy,cy,0],
           [0,0,1]])        
        
        #pitch
        cp=math.cos(pitch)
        sp=math.sin(pitch)
        pitchMatrix=numpy.matrix([[1,0,0],
                   [0,cp,-sp],
                   [0,sp,cp]])

        #roll
        cr=math.cos(roll)
        sr=math.sin(roll)
        rollMatrix=numpy.matrix([[cr,0,sr],
                   [0,1,0],
                   [-sr,0,cr]])

        vector=vector*((yawMatrix*pitchMatrix*rollMatrix))
        vector=vector.tolist()[0]
        return vector
        
        
    def unRotateVector(self,magValues,yaw,pitch,roll):
        vector=numpy.matrix([magValues])
        # yaw
        cy=math.cos(yaw)
        sy=math.sin(yaw)
        yawMatrix=numpy.matrix([[cy,-sy,0],
           [sy,cy,0],
           [0,0,1]])        
        
        #pitch
        cp=math.cos(pitch)
        sp=math.sin(pitch)
        pitchMatrix=numpy.matrix([[1,0,0],
                   [0,cp,-sp],
                   [0,sp,cp]])

        #roll
        cr=math.cos(roll)
        sr=math.sin(roll)
        rollMatrix=numpy.matrix([[cr,0,sr],
                   [0,1,0],
                   [-sr,0,cr]])

        vector=vector*((yawMatrix*pitchMatrix*rollMatrix).transpose())
        vector=vector.tolist()[0]
        return vector
        
        
    def newColumnNames(self,names):
        for colNum in self.magneticCols:
            names.append(names[colNum]+"_global")
        print names
        return names

   
if __name__=="__main__":
    # test rotation 
    p=orientedMagneticProcessor([],[])
    val= p.rotateVector((0,1,0),0,math.pi/2,math.pi/2)
    print val,math.sqrt(val[0]*val[0]+val[1]*val[1]+val[2]*val[2])
    val= p.unRotateVector(val,0,0,math.pi)
    print val,math.sqrt(val[0]*val[0]+val[1]*val[1]+val[2]*val[2])
    
    
    
    