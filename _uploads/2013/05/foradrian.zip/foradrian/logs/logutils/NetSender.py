import socket
import time
from threading import Thread,Lock,Condition

class NetSender(Thread):
    def __init__(self,dataHolder,columns,callback=None):
        Thread.__init__(self)
        self.dataHolder=dataHolder
        self.columns=[0]
        for col in columns:
            if type(col)==type(""):
                self.columns.append(dataHolder.getColumnFromName(col))
            else:
                self.columns.append(col)
        self.timeColumnName=dataHolder.getColumnName(0)
        self.connectionLock=Lock()
        self.event = Condition()
        self.currentPos=0
        self.startTimeOffset=0
        self.sendData=None
        self.quit=False
        self.callback=callback
        self.start()
        
    def run(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 19191
        s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        callback=self.callback
        lastSent=0
        while not self.quit:
            while self.sendData!=None:
                sleepTime=0
                with self.connectionLock:
                    if self.sendData!=None:
                        curTime=time.clock()
                        if callback!=None and curTime-lastSent>0.1:                            
                            callback.onPlayTime(self.sendData[self.currentPos][self.timeColumnName])
                            lastSent=curTime
                        for colname,item in self.sendData[self.currentPos].items():
                            if colname!=self.timeColumnName:
                                msg="%s %s;\n"%(item,colname)
                                s.sendto(msg,(UDP_IP,UDP_PORT))
                        self.currentPos+=1
                        if self.currentPos < len(self.sendData):
                            logicalTime=curTime + self.startTimeOffset
                            sleepTime=self.sendData[self.currentPos][self.timeColumnName]-logicalTime
                        else:
                            self.sendData=None
                if sleepTime>0:
                    time.sleep(sleepTime)
            with self.event:
                if not self.quit:
                    self.event.wait()        
        
    def startPlaying(self,startLogicalTime):
        with self.connectionLock:
            self.sendData,minPos,maxPos=self.dataHolder.getRange((startLogicalTime,self.dataHolder.getMaxTime()),self.columns)
            self.startTimeOffset=startLogicalTime -time.clock()
            self.currentPos=0
        with self.event:
            self.event.notifyAll()
            
    def stopPlaying(self):
        with self.connectionLock:
            self.sendData=None
            
    def isPlaying(self):
        with self.connectionLock:
            areWePlaying=(self.sendData!=None)
        return areWePlaying
            
    def shutdown(self):
        self.quit=True
        self.stopPlaying()
        with self.event:
            self.event.notifyAll()
            
    def getCurrentTime(self):
        curTime=time.clock()
        logicalTime=curTime + self.startTimeOffset
        return logicalTime
        
        
        
            
if __name__=="__main__":
    from CSVHolder import *
    holder=CSVHolder("..\swim-20130226-081828.csv")
    sender=NetSender(holder,[1,2,3])
    sender.startPlaying(holder.getMinTime())
    time.sleep(1000)
    print "woo"